<?php

/*
Plugin Name: Installation du TD Wordpress
Plugin URI: http://lcprod.net/
Description: Permet l'installation du TD Wordpress. (Réglages -> TD Wordpress)
Author: LCProd - Grandadam Emmanuel
Author URI: http://lcprod.net/
Version: 1
*/



/* Menu du plugin
-------------------------------------*/
function install_tdwordpress_menu() {
	#add_options_page('Plugin Admin Options', 'TD Wordpress', 'manage_options','tdwordpress', 'tdwordpress_options_page');
	
		global $wpdb;
			
			
			$url =  get_bloginfo('wpurl');

			$wpdb->query("TRUNCATE `wp_commentmeta`");
			$wpdb->query("TRUNCATE `wp_comments`");
			$wpdb->query("TRUNCATE `wp_links`");
			$wpdb->query("TRUNCATE `wp_options`");
			$wpdb->query("TRUNCATE `wp_postmeta`");
			$wpdb->query("TRUNCATE `wp_posts`");
			$wpdb->query("TRUNCATE `wp_terms`");
			$wpdb->query("TRUNCATE `wp_term_relationships`");
			$wpdb->query("TRUNCATE `wp_term_taxonomy`");
			$wpdb->query("TRUNCATE `wp_usermeta`");
			$wpdb->query("TRUNCATE `wp_users`");
			
			$sql = file("../wp-content/plugins/td_wordpress/td_wordpress.sql");

			foreach ($sql as $line){

				if (substr($line, 0, 2) == '--' || substr($line, 0, 2) == '/*' || $line == ''){
					continue;
				}
      	
				$templine .= $line;
      	
				if (substr(trim($line), -1, 1) == ';'){
						$wpdb->query($templine);
						//echo $templine."<br/>";
				    $templine = '';
				}
			}
			
			$wpdb->update(
			    $wpdb->prefix.'options', array('option_value' => $url), array('option_name' => 'siteurl')
			);
			$wpdb->update(
			    $wpdb->prefix.'options', array('option_value' => $url), array('option_name' => 'home')
			);


			$path = get_home_path()."wp-content/themes/";
			
			$zip = new ZipArchive(); 
			$zip->open('../wp-content/plugins/td_wordpress/td_wordpress.theme.zip');
			$zip->extractTo($path);
			$zip->close();
			
			$site = site_url();

	
}
add_action('admin_menu', 'install_tdwordpress_menu');
