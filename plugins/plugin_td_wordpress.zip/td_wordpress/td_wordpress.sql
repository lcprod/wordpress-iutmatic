-- phpMyAdmin SQL Dump
-- version 4.1.9
-- http://www.phpmyadmin.net
--
-- Client :  127.0.0.1
-- Généré le :  Lun 31 Août 2015 à 08:39
-- Version du serveur :  5.6.15
-- Version de PHP :  5.5.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données :  `wordpress`
--

-- --------------------------------------------------------

--
-- Structure de la table `wp_commentmeta`
--

CREATE TABLE IF NOT EXISTS `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `wp_comments`
--

CREATE TABLE IF NOT EXISTS `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `wp_links`
--

CREATE TABLE IF NOT EXISTS `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=10 ;

--
-- Contenu de la table `wp_links`
--

INSERT INTO `wp_links` (`link_id`, `link_url`, `link_name`, `link_image`, `link_target`, `link_description`, `link_visible`, `link_owner`, `link_rating`, `link_updated`, `link_rel`, `link_notes`, `link_rss`) VALUES
(5, 'http://wordpress.org/extend/plugins/', 'Plugins', '', '', '', 'Y', 1, 0, '0000-00-00 00:00:00', '', '', ''),
(6, 'http://wordpress.org/extend/themes/', 'Themes', '', '', '', 'Y', 1, 0, '0000-00-00 00:00:00', '', '', ''),
(8, 'http://127.0.0.1/wordpress/wp-admin', 'Administration', '', '', '', 'Y', 1, 0, '0000-00-00 00:00:00', '', '', ''),
(9, 'http://dl.lcprod.net/iut', 'Cours/TD', '', '_blank', '', 'Y', 1, 0, '0000-00-00 00:00:00', '', '', '');

-- --------------------------------------------------------

--
-- Structure de la table `wp_options`
--

CREATE TABLE IF NOT EXISTS `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=714 ;

--
-- Contenu de la table `wp_options`
--

INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://127.0.0.1/wordpress', 'yes'),
(2, 'blogname', 'TD Wordpress', 'yes'),
(3, 'blogdescription', 'Un site utilisant WordPress', 'yes'),
(4, 'users_can_register', '0', 'yes'),
(5, 'admin_email', 'iutmatic@gmail.com', 'yes'),
(6, 'start_of_week', '1', 'yes'),
(7, 'use_balanceTags', '1', 'yes'),
(8, 'use_smilies', '1', 'yes'),
(9, 'require_name_email', '1', 'yes'),
(10, 'comments_notify', '', 'yes'),
(11, 'posts_per_rss', '10', 'yes'),
(12, 'rss_use_excerpt', '1', 'yes'),
(13, 'mailserver_url', 'mail.example.com', 'yes'),
(14, 'mailserver_login', 'login@example.com', 'yes'),
(15, 'mailserver_pass', 'password', 'yes'),
(16, 'mailserver_port', '110', 'yes'),
(17, 'default_category', '1', 'yes'),
(18, 'default_comment_status', 'closed', 'yes'),
(19, 'default_ping_status', 'closed', 'yes'),
(20, 'default_pingback_flag', '', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'j F Y', 'yes'),
(24, 'time_format', 'G \\h i \\m\\i\\n', 'yes'),
(25, 'links_updated_date_format', 'j F Y, G \\h i \\m\\i\\n', 'yes'),
(29, 'comment_moderation', '1', 'yes'),
(30, 'moderation_notify', '', 'yes'),
(31, 'permalink_structure', '/%postname%/', 'yes'),
(32, 'gzipcompression', '0', 'yes'),
(33, 'hack_file', '0', 'yes'),
(34, 'blog_charset', 'UTF-8', 'yes'),
(35, 'moderation_keys', '', 'no'),
(36, 'active_plugins', 'a:0:{}', 'yes'),
(37, 'home', 'http://127.0.0.1/wordpress', 'yes'),
(38, 'category_base', '', 'yes'),
(39, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(40, 'advanced_edit', '0', 'yes'),
(41, 'comment_max_links', '2', 'yes'),
(42, 'gmt_offset', '', 'yes'),
(43, 'default_email_category', '1', 'yes'),
(44, 'recently_edited', 'a:2:{i:0;s:75:"style.css";i:1;b:0;}', 'yes'),
(45, 'template', 'td_wordpress', 'yes'),
(46, 'stylesheet', 'td_wordpress', 'yes'),
(47, 'comment_whitelist', '', 'yes'),
(48, 'blacklist_keys', '', 'no'),
(49, 'comment_registration', '1', 'yes'),
(51, 'html_type', 'text/html', 'yes'),
(52, 'use_trackback', '0', 'yes'),
(53, 'default_role', 'subscriber', 'yes'),
(54, 'db_version', '33055', 'yes'),
(55, 'uploads_use_yearmonth_folders', '1', 'yes'),
(56, 'upload_path', '', 'yes'),
(57, 'blog_public', '0', 'yes'),
(58, 'default_link_category', '2', 'yes'),
(59, 'show_on_front', 'page', 'yes'),
(60, 'tag_base', '', 'yes'),
(61, 'show_avatars', '1', 'yes'),
(62, 'avatar_rating', 'G', 'yes'),
(63, 'upload_url_path', '', 'yes'),
(64, 'thumbnail_size_w', '150', 'yes'),
(65, 'thumbnail_size_h', '150', 'yes'),
(66, 'thumbnail_crop', '1', 'yes'),
(67, 'medium_size_w', '300', 'yes'),
(68, 'medium_size_h', '300', 'yes'),
(69, 'avatar_default', 'gravatar_default', 'yes'),
(72, 'large_size_w', '1024', 'yes'),
(73, 'large_size_h', '1024', 'yes'),
(74, 'image_default_link_type', 'file', 'yes'),
(75, 'image_default_size', '', 'yes'),
(76, 'image_default_align', '', 'yes'),
(77, 'close_comments_for_old_posts', '', 'yes'),
(78, 'close_comments_days_old', '14', 'yes'),
(79, 'thread_comments', '1', 'yes'),
(80, 'thread_comments_depth', '5', 'yes'),
(81, 'page_comments', '', 'yes'),
(82, 'comments_per_page', '50', 'yes'),
(83, 'default_comments_page', 'newest', 'yes'),
(84, 'comment_order', 'asc', 'yes'),
(85, 'sticky_posts', 'a:0:{}', 'yes'),
(86, 'widget_categories', 'a:3:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}i:3;a:4:{s:5:"title";s:9:"Exercices";s:5:"count";i:0;s:12:"hierarchical";i:1;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(87, 'widget_text', 'a:2:{i:2;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(88, 'widget_rss', 'a:2:{i:2;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(89, 'timezone_string', 'Europe/Paris', 'yes'),
(91, 'embed_size_w', '', 'yes'),
(92, 'embed_size_h', '600', 'yes'),
(93, 'page_for_posts', '0', 'yes'),
(94, 'page_on_front', '6', 'yes'),
(95, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:62:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:9:"add_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(96, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(97, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(98, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(99, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(100, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(101, 'sidebars_widgets', 'a:4:{s:19:"wp_inactive_widgets";a:13:{i:0;s:7:"pages-2";i:1;s:10:"calendar-2";i:2;s:7:"links-2";i:3;s:6:"text-2";i:4;s:5:"rss-2";i:5;s:11:"tag_cloud-2";i:6;s:10:"nav_menu-2";i:7;s:8:"search-2";i:8;s:14:"recent-posts-2";i:9;s:17:"recent-comments-2";i:10;s:10:"archives-2";i:11;s:12:"categories-2";i:12;s:6:"meta-2";}s:9:"sidebar-1";a:2:{i:0;s:12:"categories-3";i:1;s:7:"links-3";}s:9:"sidebar-2";N;s:13:"array_version";i:3;}', 'yes'),
(102, 'cron', 'a:6:{i:1441025790;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1441038688;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1441038697;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1441043520;a:1:{s:20:"wp_maybe_auto_update";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}s:20:"wp_batch_split_terms";a:5:{i:1441010318;a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:2:{s:8:"schedule";b:0;s:4:"args";a:0:{}}}i:1441010321;a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:2:{s:8:"schedule";b:0;s:4:"args";a:0:{}}}i:1441010323;a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:2:{s:8:"schedule";b:0;s:4:"args";a:0:{}}}i:1441010329;a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:2:{s:8:"schedule";b:0;s:4:"args";a:0:{}}}i:1441010330;a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:2:{s:8:"schedule";b:0;s:4:"args";a:0:{}}}}s:7:"version";i:2;}', 'yes'),
(109, 'widget_pages', 'a:2:{i:2;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(110, 'widget_calendar', 'a:2:{i:2;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(111, 'widget_links', 'a:3:{i:2;a:0:{}i:3;a:5:{s:6:"images";i:1;s:4:"name";i:1;s:11:"description";i:0;s:6:"rating";i:0;s:8:"category";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(112, 'widget_tag_cloud', 'a:2:{i:2;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(113, 'widget_nav_menu', 'a:2:{i:2;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(114, 'dashboard_widget_options', 'a:4:{s:25:"dashboard_recent_comments";a:1:{s:5:"items";i:5;}s:24:"dashboard_incoming_links";a:5:{s:4:"home";s:29:"http://127.0.0.1/wordpress";s:4:"link";s:105:"http://blogsearch.google.com/blogsearch?scoring=d&partner=wordpress&q=link:http://127.0.0.1/wordpress/";s:3:"url";s:138:"http://blogsearch.google.com/blogsearch_feeds?scoring=d&ie=utf-8&num=10&output=rss&partner=wordpress&q=link:http://127.0.0.1/TD_Wordpress/";s:5:"items";i:10;s:9:"show_date";b:0;}s:17:"dashboard_primary";a:7:{s:4:"link";s:35:"http://www.wordpress-fr.net/planet/";s:3:"url";s:55:"http://feeds2.feedburner.com/WordpressFrancophonePlanet";s:5:"title";s:14:"Blog WordPress";s:5:"items";i:2;s:12:"show_summary";i:1;s:11:"show_author";i:0;s:9:"show_date";i:1;}s:19:"dashboard_secondary";a:7:{s:4:"link";s:35:"http://www.wordpress-fr.net/planet/";s:3:"url";s:55:"http://feeds2.feedburner.com/WordpressFrancophonePlanet";s:5:"title";s:46:"Autres actualités de WordPress (en français)";s:5:"items";i:5;s:12:"show_summary";i:0;s:11:"show_author";i:0;s:9:"show_date";i:0;}}', 'yes'),
(145, 'widget_campaign_monitor', 'a:2:{i:2;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(146, 'widget_bueno_featured', 'a:2:{i:2;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(147, 'woo_framework_version', '2.8.1', 'yes'),
(148, 'woo_template', 'a:34:{i:0;a:2:{s:4:"name";s:16:"General Settings";s:4:"type";s:7:"heading";}i:1;a:6:{s:4:"name";s:16:"Theme Stylesheet";s:4:"desc";s:44:"Select your themes alternative color scheme.";s:2:"id";s:18:"woo_alt_stylesheet";s:3:"std";s:11:"default.css";s:4:"type";s:6:"select";s:7:"options";a:7:{i:0;s:8:"blue.css";i:1;s:9:"brown.css";i:2;s:11:"default.css";i:3;s:9:"green.css";i:4;s:8:"grey.css";i:5;s:10:"purple.css";i:6;s:7:"red.css";}}i:2;a:5:{s:4:"name";s:11:"Custom Logo";s:4:"desc";s:110:"Upload a logo for your theme, or specify the image address of your online logo. (http://yoursite.com/logo.png)";s:2:"id";s:8:"woo_logo";s:3:"std";s:0:"";s:4:"type";s:6:"upload";}i:3;a:5:{s:4:"name";s:10:"Text Title";s:4:"desc";s:109:"Enable if you want Blog Title and Tagline to be text-based. Setup title/tagline in WP -> Settings -> General.";s:2:"id";s:13:"woo_texttitle";s:3:"std";s:5:"false";s:4:"type";s:8:"checkbox";}i:4;a:5:{s:4:"name";s:14:"Custom Favicon";s:4:"desc";s:78:"Upload a 16px x 16px Png/Gif image that will represent your website''s favicon.";s:2:"id";s:18:"woo_custom_favicon";s:3:"std";s:0:"";s:4:"type";s:6:"upload";}i:5;a:5:{s:4:"name";s:13:"Tracking Code";s:4:"desc";s:117:"Paste your Google Analytics (or other) tracking code here. This will be added into the footer template of your theme.";s:2:"id";s:20:"woo_google_analytics";s:3:"std";s:0:"";s:4:"type";s:8:"textarea";}i:6;a:5:{s:4:"name";s:7:"RSS URL";s:4:"desc";s:51:"Enter your preferred RSS URL. (Feedburner or other)";s:2:"id";s:18:"woo_feedburner_url";s:3:"std";s:0:"";s:4:"type";s:4:"text";}i:7;a:5:{s:4:"name";s:10:"E-Mail URL";s:4:"desc";s:67:"Enter your preferred E-mail subscription URL. (Feedburner or other)";s:2:"id";s:17:"woo_feedburner_id";s:3:"std";s:0:"";s:4:"type";s:4:"text";}i:8;a:5:{s:4:"name";s:10:"Custom CSS";s:4:"desc";s:62:"Quickly add some CSS to your theme by adding it to this block.";s:2:"id";s:14:"woo_custom_css";s:3:"std";s:0:"";s:4:"type";s:8:"textarea";}i:9;a:2:{s:4:"name";s:18:"Navigation Options";s:4:"type";s:7:"heading";}i:10;a:5:{s:4:"name";s:43:"Exclude Pages or Categories from Navigation";s:4:"desc";s:159:"Enter a comma-separated list of <a href=''http://support.wordpress.com/pages/8/''>ID''s</a> that you''d like to exclude from the top navigation. (e.g. 12,23,27,44)";s:2:"id";s:15:"woo_nav_exclude";s:3:"std";s:0:"";s:4:"type";s:4:"text";}i:11;a:5:{s:4:"name";s:16:"Use Breadcrumbs?";s:4:"desc";s:62:"Check this box if you''d like to enable the use of breadcrumbs.";s:2:"id";s:15:"woo_breadcrumbs";s:3:"std";s:5:"false";s:4:"type";s:8:"checkbox";}i:12;a:2:{s:4:"name";s:14:"Dynamic Images";s:4:"type";s:7:"heading";}i:13;a:5:{s:4:"name";s:28:"Enable Dynamic Image Resizer";s:4:"desc";s:81:"This will enable the thumb.php script. It dynamicaly resizes images on your site.";s:2:"id";s:10:"woo_resize";s:3:"std";s:4:"true";s:4:"type";s:8:"checkbox";}i:14;a:5:{s:4:"name";s:22:"Automatic Image Thumbs";s:4:"desc";s:96:"If no image is specified in the ''image'' custom field then the first uploaded post image is used.";s:2:"id";s:12:"woo_auto_img";s:3:"std";s:5:"false";s:4:"type";s:8:"checkbox";}i:15;a:5:{s:4:"name";s:16:"Image Dimensions";s:4:"desc";s:109:"Enter an integer value i.e. 250 for the desired size which will be used when dynamically creating the images.";s:2:"id";s:20:"woo_image_dimensions";s:3:"std";s:0:"";s:4:"type";a:2:{i:0;a:4:{s:2:"id";s:19:"woo_get_image_width";s:4:"type";s:4:"text";s:3:"std";i:200;s:4:"meta";s:5:"Width";}i:1;a:4:{s:2:"id";s:20:"woo_get_image_height";s:4:"type";s:4:"text";s:3:"std";i:500;s:4:"meta";s:6:"Height";}}}i:16;a:2:{s:4:"name";s:32:"Ads - Sidebar Widget (300x250px)";s:4:"type";s:7:"heading";}i:17;a:5:{s:4:"name";s:12:"Adsense code";s:4:"desc";s:56:"Enter your adsense code (or other ad network code) here.";s:2:"id";s:18:"woo_ad_300_adsense";s:3:"std";s:0:"";s:4:"type";s:8:"textarea";}i:18;a:5:{s:4:"name";s:14:"Image Location";s:4:"desc";s:33:"Enter the URL for this banner ad.";s:2:"id";s:16:"woo_ad_300_image";s:3:"std";s:41:"http://www.woothemes.com/ads/300x250b.jpg";s:4:"type";s:6:"upload";}i:19;a:5:{s:4:"name";s:15:"Destination URL";s:4:"desc";s:45:"Enter the URL where this banner ad points to.";s:2:"id";s:14:"woo_ad_300_url";s:3:"std";s:24:"http://www.woothemes.com";s:4:"type";s:4:"text";}i:20;a:2:{s:4:"name";s:37:"Banner Ads Sidebar - Widget (125x125)";s:4:"type";s:7:"heading";}i:21;a:5:{s:4:"name";s:15:"Rotate banners?";s:4:"desc";s:45:"Check this to randomly rotate the banner ads.";s:2:"id";s:14:"woo_ads_rotate";s:3:"std";s:4:"true";s:4:"type";s:8:"checkbox";}i:22;a:5:{s:4:"name";s:29:"Banner Ad #1 - Image Location";s:4:"desc";s:33:"Enter the URL for this banner ad.";s:2:"id";s:14:"woo_ad_image_1";s:3:"std";s:41:"http://www.woothemes.com/ads/125x125b.jpg";s:4:"type";s:4:"text";}i:23;a:5:{s:4:"name";s:26:"Banner Ad #1 - Destination";s:4:"desc";s:45:"Enter the URL where this banner ad points to.";s:2:"id";s:12:"woo_ad_url_1";s:3:"std";s:24:"http://www.woothemes.com";s:4:"type";s:4:"text";}i:24;a:5:{s:4:"name";s:29:"Banner Ad #2 - Image Location";s:4:"desc";s:33:"Enter the URL for this banner ad.";s:2:"id";s:14:"woo_ad_image_2";s:3:"std";s:41:"http://www.woothemes.com/ads/125x125b.jpg";s:4:"type";s:4:"text";}i:25;a:5:{s:4:"name";s:26:"Banner Ad #2 - Destination";s:4:"desc";s:45:"Enter the URL where this banner ad points to.";s:2:"id";s:12:"woo_ad_url_2";s:3:"std";s:24:"http://www.woothemes.com";s:4:"type";s:4:"text";}i:26;a:5:{s:4:"name";s:29:"Banner Ad #3 - Image Location";s:4:"desc";s:33:"Enter the URL for this banner ad.";s:2:"id";s:14:"woo_ad_image_3";s:3:"std";s:41:"http://www.woothemes.com/ads/125x125b.jpg";s:4:"type";s:4:"text";}i:27;a:5:{s:4:"name";s:26:"Banner Ad #3 - Destination";s:4:"desc";s:45:"Enter the URL where this banner ad points to.";s:2:"id";s:12:"woo_ad_url_3";s:3:"std";s:24:"http://www.woothemes.com";s:4:"type";s:4:"text";}i:28;a:5:{s:4:"name";s:29:"Banner Ad #4 - Image Location";s:4:"desc";s:33:"Enter the URL for this banner ad.";s:2:"id";s:14:"woo_ad_image_4";s:3:"std";s:41:"http://www.woothemes.com/ads/125x125b.jpg";s:4:"type";s:4:"text";}i:29;a:5:{s:4:"name";s:26:"Banner Ad #4 - Destination";s:4:"desc";s:45:"Enter the URL where this banner ad points to.";s:2:"id";s:12:"woo_ad_url_4";s:3:"std";s:24:"http://www.woothemes.com";s:4:"type";s:4:"text";}i:30;a:5:{s:4:"name";s:29:"Banner Ad #5 - Image Location";s:4:"desc";s:33:"Enter the URL for this banner ad.";s:2:"id";s:14:"woo_ad_image_5";s:3:"std";s:41:"http://www.woothemes.com/ads/125x125b.jpg";s:4:"type";s:4:"text";}i:31;a:5:{s:4:"name";s:26:"Banner Ad #5 - Destination";s:4:"desc";s:45:"Enter the URL where this banner ad points to.";s:2:"id";s:12:"woo_ad_url_5";s:3:"std";s:24:"http://www.woothemes.com";s:4:"type";s:4:"text";}i:32;a:5:{s:4:"name";s:29:"Banner Ad #6 - Image Location";s:4:"desc";s:33:"Enter the URL for this banner ad.";s:2:"id";s:14:"woo_ad_image_6";s:3:"std";s:41:"http://www.woothemes.com/ads/125x125b.jpg";s:4:"type";s:4:"text";}i:33;a:5:{s:4:"name";s:26:"Banner Ad #6 - Destination";s:4:"desc";s:45:"Enter the URL where this banner ad points to.";s:2:"id";s:12:"woo_ad_url_6";s:3:"std";s:24:"http://www.woothemes.com";s:4:"type";s:4:"text";}}', 'yes'),
(149, 'woo_themename', 'Bueno', 'yes'),
(150, 'woo_shortname', 'woo', 'yes'),
(151, 'woo_manual', 'http://www.woothemes.com/support/theme-documentation/bueno/', 'yes'),
(152, 'woo_custom_template', 'a:1:{s:5:"image";a:5:{s:4:"name";s:5:"image";s:7:"default";s:0:"";s:5:"label";s:5:"Image";s:4:"type";s:6:"upload";s:4:"desc";s:64:"Enter the URL for image to be used by the Dynamic Image resizer.";}}', 'yes'),
(153, 'woo_options', 'a:30:{s:14:"woo_ads_rotate";s:4:"true";s:18:"woo_ad_300_adsense";s:0:"";s:16:"woo_ad_300_image";s:41:"http://www.woothemes.com/ads/300x250b.jpg";s:14:"woo_ad_300_url";s:24:"http://www.woothemes.com";s:14:"woo_ad_image_1";s:41:"http://www.woothemes.com/ads/125x125b.jpg";s:14:"woo_ad_image_2";s:41:"http://www.woothemes.com/ads/125x125b.jpg";s:14:"woo_ad_image_3";s:41:"http://www.woothemes.com/ads/125x125b.jpg";s:14:"woo_ad_image_4";s:41:"http://www.woothemes.com/ads/125x125b.jpg";s:14:"woo_ad_image_5";s:41:"http://www.woothemes.com/ads/125x125b.jpg";s:14:"woo_ad_image_6";s:41:"http://www.woothemes.com/ads/125x125b.jpg";s:12:"woo_ad_url_1";s:24:"http://www.woothemes.com";s:12:"woo_ad_url_2";s:24:"http://www.woothemes.com";s:12:"woo_ad_url_3";s:24:"http://www.woothemes.com";s:12:"woo_ad_url_4";s:24:"http://www.woothemes.com";s:12:"woo_ad_url_5";s:24:"http://www.woothemes.com";s:12:"woo_ad_url_6";s:24:"http://www.woothemes.com";s:18:"woo_alt_stylesheet";s:8:"grey.css";s:12:"woo_auto_img";s:5:"false";s:15:"woo_breadcrumbs";s:5:"false";s:14:"woo_custom_css";s:0:"";s:18:"woo_custom_favicon";s:0:"";s:17:"woo_feedburner_id";s:0:"";s:18:"woo_feedburner_url";s:0:"";s:20:"woo_get_image_height";s:3:"500";s:19:"woo_get_image_width";s:3:"200";s:20:"woo_google_analytics";s:0:"";s:8:"woo_logo";s:0:"";s:15:"woo_nav_exclude";s:0:"";s:10:"woo_resize";s:4:"true";s:13:"woo_texttitle";s:5:"false";}', 'yes'),
(154, 'woo_alt_stylesheet', 'grey.css', 'yes'),
(155, 'woo_logo', '', 'yes'),
(156, 'woo_texttitle', 'false', 'yes'),
(157, 'woo_custom_favicon', '', 'yes'),
(158, 'woo_google_analytics', '', 'yes'),
(159, 'woo_feedburner_url', '', 'yes'),
(160, 'woo_feedburner_id', '', 'yes'),
(161, 'woo_custom_css', '', 'yes'),
(162, 'woo_nav_exclude', '', 'yes'),
(163, 'woo_breadcrumbs', 'false', 'yes'),
(164, 'woo_resize', 'true', 'yes'),
(165, 'woo_auto_img', 'false', 'yes'),
(166, 'woo_get_image_width', '200', 'yes'),
(167, 'woo_get_image_height', '500', 'yes'),
(168, 'woo_ad_300_adsense', '', 'yes'),
(169, 'woo_ad_300_image', 'http://www.woothemes.com/ads/300x250b.jpg', 'yes'),
(170, 'woo_ad_300_url', 'http://www.woothemes.com', 'yes'),
(171, 'woo_ads_rotate', 'true', 'yes'),
(172, 'woo_ad_image_1', 'http://www.woothemes.com/ads/125x125b.jpg', 'yes'),
(173, 'woo_ad_url_1', 'http://www.woothemes.com', 'yes'),
(174, 'woo_ad_image_2', 'http://www.woothemes.com/ads/125x125b.jpg', 'yes'),
(175, 'woo_ad_url_2', 'http://www.woothemes.com', 'yes'),
(176, 'woo_ad_image_3', 'http://www.woothemes.com/ads/125x125b.jpg', 'yes'),
(177, 'woo_ad_url_3', 'http://www.woothemes.com', 'yes'),
(178, 'woo_ad_image_4', 'http://www.woothemes.com/ads/125x125b.jpg', 'yes'),
(179, 'woo_ad_url_4', 'http://www.woothemes.com', 'yes'),
(180, 'woo_ad_image_5', 'http://www.woothemes.com/ads/125x125b.jpg', 'yes'),
(181, 'woo_ad_url_5', 'http://www.woothemes.com', 'yes'),
(182, 'woo_ad_image_6', 'http://www.woothemes.com/ads/125x125b.jpg', 'yes'),
(183, 'woo_ad_url_6', 'http://www.woothemes.com', 'yes'),
(184, 'woo_settings_custom_nav_advanced_options', 'yes', 'yes'),
(185, 'woo_custom_seo_template', 'a:4:{i:0;a:5:{s:4:"name";s:10:"seo_follow";s:3:"std";s:5:"false";s:5:"label";s:21:"SEO - Remove Nofollow";s:4:"type";s:8:"checkbox";s:4:"desc";s:59:"Make link from this post/page followable by search engines.";}i:1;a:5:{s:4:"name";s:9:"seo_title";s:3:"std";s:0:"";s:5:"label";s:23:"SEO - Custom Page Title";s:4:"type";s:4:"text";s:4:"desc";s:38:"Add a custom title for this post/page.";}i:2;a:5:{s:4:"name";s:15:"seo_description";s:3:"std";s:0:"";s:5:"label";s:24:"SEO - Custom Description";s:4:"type";s:8:"textarea";s:4:"desc";s:49:"Add a custom meta description for this post/page.";}i:3;a:5:{s:4:"name";s:12:"seo_keywords";s:3:"std";s:0:"";s:5:"label";s:21:"SEO - Custom Keywords";s:4:"type";s:4:"text";s:4:"desc";s:64:"Add a custom meta keywords for this post/page. (comma seperated)";}}', 'yes'),
(186, 'woo_settings_encode', 'PHVsPjxsaT48c3Ryb25nPndvb19hZHNfcm90YXRlPC9zdHJvbmc+IC0gdHJ1ZTwvbGk+PGxpPjxzdHJvbmc+d29vX2FkXzMwMF9hZHNlbnNlPC9zdHJvbmc+IC0gPC9saT48bGk+PHN0cm9uZz53b29fYWRfMzAwX2ltYWdlPC9zdHJvbmc+IC0gaHR0cDovL3d3dy53b290aGVtZXMuY29tL2Fkcy8zMDB4MjUwYi5qcGc8L2xpPjxsaT48c3Ryb25nPndvb19hZF8zMDBfdXJsPC9zdHJvbmc+IC0gaHR0cDovL3d3dy53b290aGVtZXMuY29tPC9saT48bGk+PHN0cm9uZz53b29fYWRfaW1hZ2VfMTwvc3Ryb25nPiAtIGh0dHA6Ly93d3cud29vdGhlbWVzLmNvbS9hZHMvMTI1eDEyNWIuanBnPC9saT48bGk+PHN0cm9uZz53b29fYWRfaW1hZ2VfMjwvc3Ryb25nPiAtIGh0dHA6Ly93d3cud29vdGhlbWVzLmNvbS9hZHMvMTI1eDEyNWIuanBnPC9saT48bGk+PHN0cm9uZz53b29fYWRfaW1hZ2VfMzwvc3Ryb25nPiAtIGh0dHA6Ly93d3cud29vdGhlbWVzLmNvbS9hZHMvMTI1eDEyNWIuanBnPC9saT48bGk+PHN0cm9uZz53b29fYWRfaW1hZ2VfNDwvc3Ryb25nPiAtIGh0dHA6Ly93d3cud29vdGhlbWVzLmNvbS9hZHMvMTI1eDEyNWIuanBnPC9saT48bGk+PHN0cm9uZz53b29fYWRfaW1hZ2VfNTwvc3Ryb25nPiAtIGh0dHA6Ly93d3cud29vdGhlbWVzLmNvbS9hZHMvMTI1eDEyNWIuanBnPC9saT48bGk+PHN0cm9uZz53b29fYWRfaW1hZ2VfNjwvc3Ryb25nPiAtIGh0dHA6Ly93d3cud29vdGhlbWVzLmNvbS9hZHMvMTI1eDEyNWIuanBnPC9saT48bGk+PHN0cm9uZz53b29fYWRfdXJsXzE8L3N0cm9uZz4gLSBodHRwOi8vd3d3Lndvb3RoZW1lcy5jb208L2xpPjxsaT48c3Ryb25nPndvb19hZF91cmxfMjwvc3Ryb25nPiAtIGh0dHA6Ly93d3cud29vdGhlbWVzLmNvbTwvbGk+PGxpPjxzdHJvbmc+d29vX2FkX3VybF8zPC9zdHJvbmc+IC0gaHR0cDovL3d3dy53b290aGVtZXMuY29tPC9saT48bGk+PHN0cm9uZz53b29fYWRfdXJsXzQ8L3N0cm9uZz4gLSBodHRwOi8vd3d3Lndvb3RoZW1lcy5jb208L2xpPjxsaT48c3Ryb25nPndvb19hZF91cmxfNTwvc3Ryb25nPiAtIGh0dHA6Ly93d3cud29vdGhlbWVzLmNvbTwvbGk+PGxpPjxzdHJvbmc+d29vX2FkX3VybF82PC9zdHJvbmc+IC0gaHR0cDovL3d3dy53b290aGVtZXMuY29tPC9saT48bGk+PHN0cm9uZz53b29fYWx0X3N0eWxlc2hlZXQ8L3N0cm9uZz4gLSBncmV5LmNzczwvbGk+PGxpPjxzdHJvbmc+d29vX2F1dG9faW1nPC9zdHJvbmc+IC0gZmFsc2U8L2xpPjxsaT48c3Ryb25nPndvb19icmVhZGNydW1iczwvc3Ryb25nPiAtIGZhbHNlPC9saT48bGk+PHN0cm9uZz53b29fY3VzdG9tX2Nzczwvc3Ryb25nPiAtIDwvbGk+PGxpPjxzdHJvbmc+d29vX2N1c3RvbV9mYXZpY29uPC9zdHJvbmc+IC0gPC9saT48bGk+PHN0cm9uZz53b29fZmVlZGJ1cm5lcl9pZDwvc3Ryb25nPiAtIDwvbGk+PGxpPjxzdHJvbmc+d29vX2ZlZWRidXJuZXJfdXJsPC9zdHJvbmc+IC0gPC9saT48bGk+PHN0cm9uZz53b29fZ2V0X2ltYWdlX2hlaWdodDwvc3Ryb25nPiAtIDUwMDwvbGk+PGxpPjxzdHJvbmc+d29vX2dldF9pbWFnZV93aWR0aDwvc3Ryb25nPiAtIDIwMDwvbGk+PGxpPjxzdHJvbmc+d29vX2dvb2dsZV9hbmFseXRpY3M8L3N0cm9uZz4gLSA8L2xpPjxsaT48c3Ryb25nPndvb19sb2dvPC9zdHJvbmc+IC0gPC9saT48bGk+PHN0cm9uZz53b29fbmF2X2V4Y2x1ZGU8L3N0cm9uZz4gLSA8L2xpPjxsaT48c3Ryb25nPndvb19yZXNpemU8L3N0cm9uZz4gLSB0cnVlPC9saT48bGk+PHN0cm9uZz53b29fdGV4dHRpdGxlPC9zdHJvbmc+IC0gZmFsc2U8L2xpPjwvdWw+', 'yes'),
(188, 'mods_Simplo', 'a:1:{s:18:"nav_menu_locations";a:1:{s:9:"main-menu";i:7;}}', 'yes'),
(189, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'),
(221, 'wpcumulus_options', 'a:13:{s:5:"width";s:3:"550";s:6:"height";s:3:"375";s:6:"tcolor";s:6:"ffffff";s:7:"tcolor2";s:6:"ffffff";s:7:"hicolor";s:6:"ffffff";s:7:"bgcolor";s:6:"333333";s:5:"speed";s:3:"100";s:5:"trans";s:5:"false";s:5:"distr";s:4:"true";s:4:"args";s:0:"";s:8:"compmode";s:5:"false";s:10:"showwptags";s:4:"true";s:4:"mode";s:4:"tags";}', 'yes'),
(222, 'wpcumulus_widget', 'a:14:{s:5:"width";s:3:"160";s:6:"height";s:3:"160";s:6:"tcolor";s:6:"333333";s:7:"tcolor2";s:6:"333333";s:7:"hicolor";s:6:"000000";s:7:"bgcolor";s:6:"ffffff";s:5:"speed";s:3:"100";s:5:"trans";s:0:"";s:5:"distr";s:4:"true";s:4:"args";s:0:"";s:8:"compmode";s:5:"false";s:10:"showwptags";s:4:"true";s:4:"mode";s:4:"tags";s:5:"title";s:3:"aaa";}', 'yes'),
(223, 'yoast_breadcrumbs', 'a:11:{s:4:"home";s:4:"Home";s:4:"blog";s:4:"Blog";s:3:"sep";s:7:"&raquo;";s:12:"singleparent";s:1:"6";s:6:"prefix";s:13:"You are here:";s:13:"archiveprefix";s:12:"Archives for";s:12:"searchprefix";s:10:"Search for";s:8:"boldlast";b:1;s:12:"nofollowhome";b:0;s:15:"singlecatprefix";b:1;s:8:"trytheme";b:0;}', 'yes'),
(224, 'recently_activated', 'a:8:{s:25:"db-cleaner/db-cleaner.php";i:1410936577;s:37:"simple-feed-list/simple-feed-list.php";i:1410936370;s:52:"rss-via-shortcode-on-page-post/rss-via-shortcode.php";i:1410935402;s:27:"shareaholic/shareaholic.php";i:1410934972;s:24:"simple-lightbox/main.php";i:1410934962;s:21:"sociable/sociable.php";i:1410934357;s:57:"simple-share-buttons-adder/simple-share-buttons-adder.php";i:1410934321;s:43:"social-share-button/social-share-button.php";i:1410932999;}', 'yes'),
(233, 'sociable_tagline', '<strong>Share and Enjoy:</strong>', 'yes'),
(234, 'sociable_conditionals', 'a:9:{s:7:"is_home";b:0;s:9:"is_single";b:1;s:7:"is_page";b:1;s:11:"is_category";b:0;s:6:"is_tag";b:0;s:7:"is_date";b:0;s:9:"is_search";b:0;s:9:"is_author";b:0;s:7:"is_feed";b:0;}', 'yes'),
(235, 'sociable_usecss', '1', 'yes'),
(236, 'sociable_iframewidth', '900', 'yes'),
(237, 'sociable_iframeheight', '500', 'yes'),
(238, 'sociable_active_sites', 'a:2:{i:0;s:5:"Print";i:1;s:8:"Facebook";}', 'yes'),
(239, 'sociable_awesmapikey', '', 'yes'),
(240, 'sociable_imagedir', '', 'yes'),
(241, 'share_on_facebook_options', 'a:3:{s:9:"link_type";s:4:"link";s:14:"insertion_type";s:4:"auto";s:9:"page_type";s:5:"posts";}', 'yes'),
(272, 'del_revision_no', '140', 'yes'),
(273, 'del_revision_getPosts', '0', 'yes'),
(329, 'default_post_format', '0', 'yes'),
(330, 'initial_db_version', '15477', 'yes'),
(331, 'db_upgraded', '', 'yes'),
(336, 'theme_mods_simple', 'a:3:{s:16:"background_color";s:0:"";s:18:"nav_menu_locations";a:1:{s:9:"main-menu";i:0;}s:16:"sidebars_widgets";a:2:{s:4:"time";i:1330016153;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:13:{i:0;s:7:"pages-2";i:1;s:10:"calendar-2";i:2;s:7:"links-2";i:3;s:6:"text-2";i:4;s:5:"rss-2";i:5;s:11:"tag_cloud-2";i:6;s:10:"nav_menu-2";i:7;s:8:"search-2";i:8;s:14:"recent-posts-2";i:9;s:17:"recent-comments-2";i:10;s:10:"archives-2";i:11;s:12:"categories-2";i:12;s:6:"meta-2";}s:9:"sidebar-1";a:2:{i:0;s:12:"categories-3";i:1;s:7:"links-3";}}}}', 'yes'),
(342, 'theme_mods_twentyeleven', 'a:2:{i:0;b:0;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1348656486;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:13:{i:0;s:7:"pages-2";i:1;s:10:"calendar-2";i:2;s:7:"links-2";i:3;s:6:"text-2";i:4;s:5:"rss-2";i:5;s:11:"tag_cloud-2";i:6;s:10:"nav_menu-2";i:7;s:8:"search-2";i:8;s:14:"recent-posts-2";i:9;s:17:"recent-comments-2";i:10;s:10:"archives-2";i:11;s:12:"categories-2";i:12;s:6:"meta-2";}s:18:"orphaned_widgets_1";a:2:{i:0;s:12:"categories-3";i:1;s:7:"links-3";}}}}', 'yes'),
(343, 'theme_switched', '', 'yes'),
(345, 'current_theme', 'td_wordpress', 'yes'),
(346, 'theme_mods_wordpress', 'a:10:{i:0;b:0;s:12:"header_image";s:13:"remove-header";s:16:"header_textcolor";s:6:"515151";s:18:"nav_menu_locations";a:1:{s:7:"primary";i:18;}s:16:"background_color";s:6:"e6e6e6";s:16:"background_image";s:0:"";s:17:"background_repeat";s:6:"repeat";s:21:"background_position_x";s:4:"left";s:21:"background_attachment";s:6:"scroll";s:16:"sidebars_widgets";a:2:{s:4:"time";i:1441010263;s:4:"data";a:3:{s:19:"wp_inactive_widgets";a:13:{i:0;s:7:"pages-2";i:1;s:10:"calendar-2";i:2;s:7:"links-2";i:3;s:6:"text-2";i:4;s:5:"rss-2";i:5;s:11:"tag_cloud-2";i:6;s:10:"nav_menu-2";i:7;s:8:"search-2";i:8;s:14:"recent-posts-2";i:9;s:17:"recent-comments-2";i:10;s:10:"archives-2";i:11;s:12:"categories-2";i:12;s:6:"meta-2";}s:9:"sidebar-1";a:2:{i:0;s:12:"categories-3";i:1;s:7:"links-3";}s:9:"sidebar-2";a:0:{}}}}', 'yes'),
(347, 'logged_in_key', '<Owq9m!2/85Y 1W>TTn_;r]v^|CP4Lso|I+EC>OCFLAH^ma(bS0y&R&Y)[l;3OEM', 'yes'),
(348, 'logged_in_salt', 'ezfek.XT!O|}m&)?<j]usbM+>yR)sa}H8#s25EX$5< dXfQr5BUC(gjw7u*4f?-s', 'yes'),
(352, 'auth_key', 'mqmmBOXy-Mv9i>%)F/keLSD.pz1nqO3rQb&mAoM#M?E+EWir[1^!g7D<d/LzdNvc', 'yes'),
(353, 'auth_salt', 'uWmso&.@]a2&A(t6j+XI=^*]rd[rXT%P(_y(?A_^S?3rod(`KC2)*9R?-nvSr)pb', 'yes'),
(354, 'uninstall_plugins', 'a:4:{s:43:"social-share-button/social-share-button.php";s:19:"ssb_share_uninstall";s:57:"simple-share-buttons-adder/simple-share-buttons-adder.php";s:14:"ssba_uninstall";s:27:"shareaholic/shareaholic.php";a:2:{i:0;s:11:"Shareaholic";i:1;s:9:"uninstall";}s:25:"db-cleaner/db-cleaner.php";a:2:{i:0;s:9:"dbc_setup";i:1;s:12:"on_uninstall";}}', 'no'),
(358, 'nonce_key', ')dw&GZbuPy)Z#0ufa~4B@.AQIe<5OgEhS.g1V`m+SuiyfJ]SpVC,43mVUBYNyL!|', 'yes'),
(359, 'nonce_salt', '4B|Gs#)qXBeQi26`VWj`-^_8)Y7D+73C~%em<8&1D[QAG3^{BKD  -bGoA,c_C~1', 'yes'),
(395, 'category_children', 'a:0:{}', 'yes'),
(409, 'gsxml_hp', '0', 'yes'),
(410, 'gsxml_gp', '0', 'yes'),
(411, 'gsxml_hf', 'always', 'yes'),
(412, 'gsxml_gf', 'always', 'yes'),
(413, 'gsxml_store', '1', 'yes'),
(414, 'gsxml_pri_freq', 'Disable', 'yes'),
(415, 'gsxml_cat', 'NotInclude', 'yes'),
(416, 'gsxml_tag', 'NotInclude', 'yes'),
(417, 'gsxml_last_ch', 'Disable', 'yes'),
(449, 'link_manager_enabled', '1', 'yes'),
(485, 'theme_mods_twentyfourteen', 'a:2:{i:0;b:0;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1410271017;s:4:"data";a:3:{s:19:"wp_inactive_widgets";a:13:{i:0;s:7:"pages-2";i:1;s:10:"calendar-2";i:2;s:7:"links-2";i:3;s:6:"text-2";i:4;s:5:"rss-2";i:5;s:11:"tag_cloud-2";i:6;s:10:"nav_menu-2";i:7;s:8:"search-2";i:8;s:14:"recent-posts-2";i:9;s:17:"recent-comments-2";i:10;s:10:"archives-2";i:11;s:12:"categories-2";i:12;s:6:"meta-2";}s:9:"sidebar-1";a:2:{i:0;s:12:"categories-3";i:1;s:7:"links-3";}s:9:"sidebar-2";N;}}}', 'yes'),
(488, 'optionsframework', 'a:1:{s:2:"id";s:8:"spacious";}', 'yes'),
(489, 'theme_mods_twentytwelve', 'a:2:{i:0;b:0;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1399470699;s:4:"data";a:3:{s:19:"wp_inactive_widgets";a:13:{i:0;s:7:"pages-2";i:1;s:10:"calendar-2";i:2;s:7:"links-2";i:3;s:6:"text-2";i:4;s:5:"rss-2";i:5;s:11:"tag_cloud-2";i:6;s:10:"nav_menu-2";i:7;s:8:"search-2";i:8;s:14:"recent-posts-2";i:9;s:17:"recent-comments-2";i:10;s:10:"archives-2";i:11;s:12:"categories-2";i:12;s:6:"meta-2";}s:9:"sidebar-1";a:2:{i:0;s:12:"categories-3";i:1;s:7:"links-3";}s:9:"sidebar-2";N;}}}', 'yes'),
(492, 'theme_mods_spacious', 'a:2:{i:0;b:0;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1399471167;s:4:"data";a:3:{s:19:"wp_inactive_widgets";a:13:{i:0;s:7:"pages-2";i:1;s:10:"calendar-2";i:2;s:7:"links-2";i:3;s:6:"text-2";i:4;s:5:"rss-2";i:5;s:11:"tag_cloud-2";i:6;s:10:"nav_menu-2";i:7;s:8:"search-2";i:8;s:14:"recent-posts-2";i:9;s:17:"recent-comments-2";i:10;s:10:"archives-2";i:11;s:12:"categories-2";i:12;s:6:"meta-2";}s:9:"sidebar-1";a:2:{i:0;s:12:"categories-3";i:1;s:7:"links-3";}s:9:"sidebar-2";N;}}}', 'yes'),
(527, 'WPLANG', 'fr_FR', 'yes'),
(573, 'ssb_share_version', '1.5', 'yes'),
(574, 'ssb_share_content_display', 'yes', 'yes'),
(575, 'ssb_share_content_themes', 'round', 'yes'),
(576, 'ssb_share_content_position', 'top', 'yes'),
(577, 'ssb_share_content_icon_margin', '0', 'yes'),
(578, 'ssb_share_filter_posttype', 'a:2:{s:4:"post";s:1:"1";s:4:"page";s:1:"1";}', 'yes'),
(579, 'ssb_share_target_tab', 'new', 'yes'),
(581, 'ssba_version', '4.7', 'yes'),
(582, 'ssba_image_set', 'simple', 'yes'),
(583, 'ssba_size', '35', 'yes'),
(584, 'ssba_pages', 'Y', 'yes'),
(585, 'ssba_posts', 'Y', 'yes'),
(586, 'ssba_cats_archs', '', 'yes'),
(587, 'ssba_homepage', 'Y', 'yes'),
(588, 'ssba_excerpts', '', 'yes'),
(589, 'ssba_align', 'left', 'yes'),
(590, 'ssba_padding', '6', 'yes'),
(591, 'ssba_before_or_after', 'after', 'yes'),
(592, 'ssba_custom_styles', '', 'yes'),
(593, 'ssba_email_message', '', 'yes'),
(594, 'ssba_twitter_text', '', 'yes'),
(595, 'ssba_buffer_text', '', 'yes'),
(596, 'ssba_flattr_user_id', '', 'yes'),
(597, 'ssba_flattr_url', '', 'yes'),
(598, 'ssba_share_new_window', 'Y', 'yes'),
(599, 'ssba_link_to_ssb', '', 'yes'),
(600, 'ssba_show_share_count', '', 'yes'),
(601, 'ssba_share_count_style', 'default', 'yes'),
(602, 'ssba_share_count_css', '', 'yes'),
(603, 'ssba_share_count_once', 'Y', 'yes'),
(604, 'ssba_widget_text', '', 'yes'),
(605, 'ssba_rel_nofollow', '', 'yes'),
(606, 'ssba_div_padding', '', 'yes'),
(607, 'ssba_div_rounded_corners', '', 'yes'),
(608, 'ssba_border_width', '', 'yes'),
(609, 'ssba_div_border', '#59625c', 'yes'),
(610, 'ssba_div_background', '', 'yes'),
(611, 'ssba_share_text', '', 'yes'),
(612, 'ssba_text_placement', 'left', 'yes'),
(613, 'ssba_font_family', 'Indie Flower', 'yes'),
(614, 'ssba_font_color', '', 'yes'),
(615, 'ssba_font_size', '20', 'yes'),
(616, 'ssba_font_weight', '', 'yes'),
(617, 'ssba_selected_buttons', 'google,twitter,facebook', 'yes'),
(618, 'ssba_custom_email', '', 'yes'),
(619, 'ssba_custom_google', '', 'yes'),
(620, 'ssba_custom_facebook', '', 'yes'),
(621, 'ssba_custom_twitter', '', 'yes'),
(622, 'ssba_custom_diggit', '', 'yes'),
(623, 'ssba_custom_linkedin', '', 'yes'),
(624, 'ssba_custom_reddit', '', 'yes'),
(625, 'ssba_custom_stumbleupon', '', 'yes'),
(626, 'ssba_custom_pinterest', '', 'yes'),
(627, 'ssba_custom_buffer', '', 'yes'),
(628, 'ssba_custom_flattr', '', 'yes'),
(629, 'ssba_custom_tumblr', '', 'yes'),
(630, 'ssba_custom_print', '', 'yes'),
(645, 'shareaholic_settings', 'a:14:{s:16:"disable_tracking";s:3:"off";s:22:"disable_admin_bar_menu";s:3:"off";s:18:"disable_debug_info";s:3:"off";s:33:"disable_internal_share_counts_api";s:3:"off";s:7:"api_key";s:32:"9f2762cea304f00dab33398be11d809a";s:16:"verification_key";s:32:"d6d1c8fb12f82cb601c74d7938ba0658";s:26:"share_counts_connect_check";s:7:"SUCCESS";s:7:"version";s:7:"7.5.1.0";s:17:"location_name_ids";a:2:{s:13:"share_buttons";a:8:{s:18:"post_above_content";i:7840096;s:18:"post_below_content";i:7840097;s:18:"page_above_content";i:7840098;s:18:"page_below_content";i:7840099;s:19:"index_above_content";i:7840100;s:19:"index_below_content";i:7840101;s:22:"category_above_content";i:7840102;s:22:"category_below_content";i:7840103;}s:15:"recommendations";a:8:{s:18:"post_below_content";i:7840104;s:18:"page_below_content";i:7840105;s:22:"category_below_content";i:7840106;s:18:"post_above_content";i:7840107;s:18:"page_above_content";i:7840108;s:19:"index_above_content";i:7840109;s:19:"index_below_content";i:7840110;s:22:"category_above_content";i:7840111;}}s:15:"recommendations";a:0:{}s:13:"share_buttons";a:8:{s:18:"post_above_content";s:2:"on";s:18:"post_below_content";s:3:"off";s:18:"page_above_content";s:3:"off";s:18:"page_below_content";s:3:"off";s:19:"index_above_content";s:3:"off";s:19:"index_below_content";s:3:"off";s:22:"category_above_content";s:3:"off";s:22:"category_below_content";s:3:"off";}s:15:"disable_og_tags";s:3:"off";s:21:"metakey_6to7_upgraded";s:4:"true";s:18:"welcome_email_sent";b:1;}', 'yes'),
(648, 'sociable_known_sites', 'a:27:{s:8:"Facebook";a:3:{s:7:"favicon";s:12:"facebook.png";s:3:"url";s:57:"http://www.facebook.com/share.php?u=PERMALINK&amp;t=TITLE";s:17:"spriteCoordinates";a:4:{i:16;a:2:{i:0;s:5:"-48px";i:1;s:3:"0px";}i:32;a:2:{i:0;s:5:"-96px";i:1;s:3:"0px";}i:48;a:2:{i:0;s:6:"-144px";i:1;s:3:"0px";}i:64;a:2:{i:0;s:6:"-192px";i:1;s:3:"0px";}}}s:16:"Facebook Counter";a:4:{s:7:"counter";i:1;s:7:"favicon";s:15:"likecounter.png";s:3:"url";s:284:"<iframe src="http://www.facebook.com/plugins/like.php?href=PERMALINKCOUNT&send=false&layout=button_count&show_faces=false&action=like&colorscheme=light&font" scrolling="no" frameborder="0" style="border:none; overflow:hidden;height:32px;width:100px" allowTransparency="true"></iframe>";s:17:"spriteCoordinates";a:4:{i:16;a:2:{i:0;s:5:"-48px";i:1;s:3:"0px";}i:32;a:2:{i:0;s:5:"-96px";i:1;s:3:"0px";}i:48;a:2:{i:0;s:6:"-144px";i:1;s:3:"0px";}i:64;a:2:{i:0;s:6:"-192px";i:1;s:3:"0px";}}}s:7:"Myspace";a:3:{s:7:"favicon";s:11:"myspace.png";s:3:"url";s:68:"http://www.myspace.com/Modules/PostTo/Pages/?u=PERMALINK&amp;t=TITLE";s:17:"spriteCoordinates";a:4:{i:16;a:2:{i:0;s:3:"0px";i:1;s:5:"-16px";}i:32;a:2:{i:0;s:3:"0px";i:1;s:5:"-32px";}i:48;a:2:{i:0;s:3:"0px";i:1;s:5:"-48px";}i:64;a:2:{i:0;s:3:"0px";i:1;s:5:"-64px";}}}s:7:"Twitter";a:3:{s:7:"favicon";s:11:"twitter.png";s:3:"url";s:71:"http://twitter.com/intent/tweet?text=TITLE%20-%20PERMALINK%20  SHARETAG";s:17:"spriteCoordinates";a:4:{i:16;a:2:{i:0;s:6:"-144px";i:1;s:5:"-16px";}i:32;a:2:{i:0;s:6:"-288px";i:1;s:5:"-32px";}i:48;a:2:{i:0;s:6:"-432px";i:1;s:5:"-48px";}i:64;a:2:{i:0;s:6:"-576px";i:1;s:5:"-64px";}}}s:15:"Twitter Counter";a:4:{s:7:"counter";i:1;s:7:"favicon";s:11:"twitter.png";s:3:"url";s:244:"<a href="https://twitter.com/share" data-text="TITLECOUNT - PERMALINKCOUNT" data-url="PERMALINKCOUNT" class="twitter-share-button" data-count="horizontal">Tweet</a><script type="text/javascript" src="//platform.twitter.com/widgets.js"></script>";s:17:"spriteCoordinates";a:4:{i:16;a:2:{i:0;s:6:"-144px";i:1;s:5:"-16px";}i:32;a:2:{i:0;s:6:"-288px";i:1;s:5:"-32px";}i:48;a:2:{i:0;s:6:"-432px";i:1;s:5:"-48px";}i:64;a:2:{i:0;s:6:"-576px";i:1;s:5:"-64px";}}}s:8:"LinkedIn";a:3:{s:7:"favicon";s:12:"linkedin.png";s:3:"url";s:120:"http://www.linkedin.com/shareArticle?mini=true&amp;url=PERMALINK&amp;title=TITLE&amp;source=BLOGNAME&amp;summary=EXCERPT";s:17:"spriteCoordinates";a:4:{i:16;a:2:{i:0;s:6:"-144px";i:1;s:3:"0px";}i:32;a:2:{i:0;s:6:"-288px";i:1;s:3:"0px";}i:48;a:2:{i:0;s:6:"-432px";i:1;s:3:"0px";}i:64;a:2:{i:0;s:6:"-576px";i:1;s:3:"0px";}}}s:16:"LinkedIn Counter";a:4:{s:7:"counter";i:1;s:7:"favicon";s:12:"linkedin.png";s:3:"url";s:161:"<script src="http://platform.linkedin.com/in.js" type="text/javascript"></script><script type="IN/Share" data-url="PERMALINKCOUNT" data-counter="right"></script>";s:17:"spriteCoordinates";a:4:{i:16;a:2:{i:0;s:6:"-144px";i:1;s:3:"0px";}i:32;a:2:{i:0;s:6:"-288px";i:1;s:3:"0px";}i:48;a:2:{i:0;s:6:"-432px";i:1;s:3:"0px";}i:64;a:2:{i:0;s:6:"-576px";i:1;s:3:"0px";}}}s:9:"Delicious";a:3:{s:7:"favicon";s:13:"delicious.png";s:3:"url";s:73:"http://delicious.com/post?url=PERMALINK&amp;title=TITLE&amp;notes=EXCERPT";s:17:"spriteCoordinates";a:4:{i:16;a:2:{i:0;s:5:"-16px";i:1;s:3:"0px";}i:32;a:2:{i:0;s:5:"-32px";i:1;s:3:"0px";}i:48;a:2:{i:0;s:5:"-48px";i:1;s:3:"0px";}i:64;a:2:{i:0;s:5:"-64px";i:1;s:3:"0px";}}}s:4:"Digg";a:3:{s:7:"favicon";s:8:"digg.png";s:3:"url";s:85:"http://digg.com/submit?phase=2&amp;url=PERMALINK&amp;title=TITLE&amp;bodytext=EXCERPT";s:17:"spriteCoordinates";a:4:{i:16;a:2:{i:0;s:5:"-32px";i:1;s:3:"0px";}i:32;a:2:{i:0;s:5:"-64px";i:1;s:3:"0px";}i:48;a:2:{i:0;s:5:"-96px";i:1;s:3:"0px";}i:64;a:2:{i:0;s:6:"-128px";i:1;s:3:"0px";}}}s:12:"Digg Counter";a:4:{s:7:"counter";i:1;s:7:"favicon";s:8:"digg.png";s:3:"url";s:372:"<script type=''text/javascript''>(function() {var s = document.createElement(''SCRIPT''), s1 = document.getElementsByTagName(''SCRIPT'')[0];s.type = ''text/javascript'';s.async = true;s.src = ''http://widgets.digg.com/buttons.js'';s1.parentNode.insertBefore(s, s1);})();</script><a href=''http://digg.com/submit?url=PERMALINK&amp;title=TITLE''  class=''DiggThisButton DiggCompact''></a>";s:17:"spriteCoordinates";a:4:{i:16;a:2:{i:0;s:5:"-32px";i:1;s:3:"0px";}i:32;a:2:{i:0;s:5:"-64px";i:1;s:3:"0px";}i:48;a:2:{i:0;s:5:"-96px";i:1;s:3:"0px";}i:64;a:2:{i:0;s:6:"-128px";i:1;s:3:"0px";}}}s:6:"Reddit";a:3:{s:7:"favicon";s:10:"reddit.png";s:3:"url";s:54:"http://reddit.com/submit?url=PERMALINK&amp;title=TITLE";s:17:"spriteCoordinates";a:4:{i:16;a:2:{i:0;s:5:"-64px";i:1;s:5:"-16px";}i:32;a:2:{i:0;s:6:"-128px";i:1;s:5:"-32px";}i:48;a:2:{i:0;s:6:"-192px";i:1;s:5:"-48px";}i:64;a:2:{i:0;s:6:"-256px";i:1;s:5:"-64px";}}}s:11:"StumbleUpon";a:3:{s:7:"favicon";s:15:"stumbleupon.png";s:3:"url";s:59:"http://www.stumbleupon.com/submit?url=PERMALINK&title=TITLE";s:17:"spriteCoordinates";a:4:{i:16;a:2:{i:0;s:6:"-112px";i:1;s:5:"-16px";}i:32;a:2:{i:0;s:6:"-224px";i:1;s:5:"-32px";}i:48;a:2:{i:0;s:6:"-336px";i:1;s:5:"-48px";}i:64;a:2:{i:0;s:6:"-448px";i:1;s:5:"-64px";}}}s:19:"StumbleUpon Counter";a:4:{s:7:"counter";i:1;s:7:"favicon";s:15:"stumbleupon.png";s:3:"url";s:87:"<script src="http://www.stumbleupon.com/hostedbadge.php?s=2&r=PERMALINKCOUNT"></script>";s:17:"spriteCoordinates";a:4:{i:16;a:2:{i:0;s:6:"-112px";i:1;s:5:"-16px";}i:32;a:2:{i:0;s:6:"-224px";i:1;s:5:"-32px";}i:48;a:2:{i:0;s:6:"-336px";i:1;s:5:"-48px";}i:64;a:2:{i:0;s:6:"-448px";i:1;s:5:"-64px";}}}s:6:"vuible";a:3:{s:7:"favicon";s:10:"vuible.png";s:3:"url";s:88:"http://vuible.com/pins-settings/?m=bm&imgsrc=SOURCE&source=PERMALINK&title=TITLE&video=0";s:17:"spriteCoordinates";a:4:{i:16;a:2:{i:0;s:6:"-112px";i:1;s:5:"-16px";}i:32;a:2:{i:0;s:6:"-224px";i:1;s:5:"-32px";}i:48;a:2:{i:0;s:6:"-336px";i:1;s:5:"-48px";}i:64;a:2:{i:0;s:6:"-448px";i:1;s:5:"-64px";}}}s:14:"vuible Counter";a:4:{s:7:"counter";i:1;s:7:"favicon";s:10:"vuible.png";s:3:"url";s:87:"<script src="http://www.stumbleupon.com/hostedbadge.php?s=2&r=PERMALINKCOUNT"></script>";s:17:"spriteCoordinates";a:4:{i:16;a:2:{i:0;s:6:"-112px";i:1;s:5:"-16px";}i:32;a:2:{i:0;s:6:"-224px";i:1;s:5:"-32px";}i:48;a:2:{i:0;s:6:"-336px";i:1;s:5:"-48px";}i:64;a:2:{i:0;s:6:"-448px";i:1;s:5:"-64px";}}}s:16:"Google Bookmarks";a:4:{s:7:"favicon";s:10:"google.png";s:3:"url";s:102:"http://www.google.com/bookmarks/mark?op=edit&amp;bkmk=PERMALINK&amp;title=TITLE&amp;annotation=EXCERPT";s:11:"description";s:16:"Google Bookmarks";s:17:"spriteCoordinates";a:4:{i:16;a:2:{i:0;s:5:"-96px";i:1;s:3:"0px";}i:32;a:2:{i:0;s:6:"-192px";i:1;s:3:"0px";}i:48;a:2:{i:0;s:6:"-288px";i:1;s:3:"0px";}i:64;a:2:{i:0;s:6:"-384px";i:1;s:3:"0px";}}}s:8:"Google +";a:5:{s:7:"counter";i:1;s:7:"favicon";s:10:"google.png";s:3:"url";s:79:"<g:plusone annotation="bubble" href="PERMALINKCOUNT" size="medium"></g:plusone>";s:11:"description";s:16:"Google Bookmarks";s:17:"spriteCoordinates";a:4:{i:16;a:2:{i:0;s:5:"-96px";i:1;s:3:"0px";}i:32;a:2:{i:0;s:6:"-192px";i:1;s:3:"0px";}i:48;a:2:{i:0;s:6:"-288px";i:1;s:3:"0px";}i:64;a:2:{i:0;s:6:"-384px";i:1;s:3:"0px";}}}s:10:"HackerNews";a:3:{s:7:"favicon";s:15:"hacker_news.png";s:3:"url";s:62:"http://news.ycombinator.com/submitlink?u=PERMALINK&amp;t=TITLE";s:17:"spriteCoordinates";a:4:{i:16;a:2:{i:0;s:6:"-128px";i:1;s:3:"0px";}i:32;a:2:{i:0;s:6:"-256px";i:1;s:3:"0px";}i:48;a:2:{i:0;s:6:"-384px";i:1;s:3:"0px";}i:64;a:2:{i:0;s:6:"-512px";i:1;s:3:"0px";}}}s:11:"MSNReporter";a:4:{s:7:"favicon";s:7:"msn.png";s:3:"url";s:121:"http://reporter.es.msn.com/?fn=contribute&amp;Title=TITLE&amp;URL=PERMALINK&amp;cat_id=6&amp;tag_id=31&amp;Remark=EXCERPT";s:11:"description";s:12:"MSN Reporter";s:17:"spriteCoordinates";a:4:{i:16;a:2:{i:0;s:6:"-176px";i:1;s:3:"0px";}i:32;a:2:{i:0;s:6:"-352px";i:1;s:3:"0px";}i:48;a:2:{i:0;s:6:"-528px";i:1;s:3:"0px";}i:64;a:2:{i:0;s:6:"-704px";i:1;s:3:"0px";}}}s:9:"BlinkList";a:4:{s:7:"favicon";s:13:"blinklist.png";s:3:"url";s:94:"http://www.blinklist.com/index.php?Action=Blink/addblink.php&amp;Url=PERMALINK&amp;Title=TITLE";s:17:"spriteCoordinates";a:4:{i:16;a:2:{i:0;s:3:"0px";i:1;s:3:"0px";}i:32;a:2:{i:0;s:3:"0px";i:1;s:3:"0px";}i:48;a:2:{i:0;s:3:"0px";i:1;s:3:"0px";}i:64;a:2:{i:0;s:3:"0px";i:1;s:3:"0px";}}s:14:"supportsIframe";b:0;}s:6:"Sphinn";a:3:{s:7:"favicon";s:10:"sphinn.png";s:3:"url";s:66:"http://sphinn.com/index.php?c=post&amp;m=submit&amp;link=PERMALINK";s:17:"spriteCoordinates";a:4:{i:16;a:2:{i:0;s:5:"-96px";i:1;s:5:"-16px";}i:32;a:2:{i:0;s:6:"-192px";i:1;s:5:"-32px";}i:48;a:2:{i:0;s:6:"-288px";i:1;s:5:"-48px";}i:64;a:2:{i:0;s:6:"-384px";i:1;s:5:"-64px";}}}s:9:"Posterous";a:3:{s:7:"favicon";s:13:"posterous.png";s:3:"url";s:81:"http://posterous.com/share?linkto=PERMALINK&amp;title=TITLE&amp;selection=EXCERPT";s:17:"spriteCoordinates";a:4:{i:16;a:2:{i:0;s:5:"-32px";i:1;s:5:"-16px";}i:32;a:2:{i:0;s:5:"-64px";i:1;s:5:"-32px";}i:48;a:2:{i:0;s:5:"-96px";i:1;s:5:"-48px";}i:64;a:2:{i:0;s:6:"-128px";i:1;s:5:"-64px";}}}s:6:"Tumblr";a:4:{s:7:"favicon";s:10:"tumblr.png";s:3:"url";s:73:"http://www.tumblr.com/share?v=3&amp;u=PERMALINK&amp;t=TITLE&amp;s=EXCERPT";s:17:"spriteCoordinates";a:4:{i:16;a:2:{i:0;s:6:"-128px";i:1;s:5:"-16px";}i:32;a:2:{i:0;s:6:"-256px";i:1;s:5:"-32px";}i:48;a:2:{i:0;s:6:"-384px";i:1;s:5:"-48px";}i:64;a:2:{i:0;s:6:"-512px";i:1;s:5:"-64px";}}s:14:"supportsIframe";b:0;}s:5:"email";a:4:{s:7:"favicon";s:9:"gmail.png";s:3:"url";s:86:"https://mail.google.com/mail/?view=cm&fs=1&to&su=TITLE&body=PERMALINK&ui=2&tf=1&shva=1";s:17:"spriteCoordinates";a:4:{i:16;a:2:{i:0;s:5:"-80px";i:1;s:3:"0px";}i:32;a:2:{i:0;s:6:"-160px";i:1;s:3:"0px";}i:48;a:2:{i:0;s:6:"-240px";i:1;s:3:"0px";}i:64;a:2:{i:0;s:6:"-320px";i:1;s:3:"0px";}}s:14:"supportsIframe";b:0;}s:13:"Google Reader";a:3:{s:7:"favicon";s:14:"googlebuzz.png";s:3:"url";s:106:"http://www.google.com/reader/link?url=PERMALINK&amp;title=TITLE&amp;srcURL=PERMALINK&amp;srcTitle=BLOGNAME";s:17:"spriteCoordinates";a:4:{i:16;a:2:{i:0;s:6:"-112px";i:1;s:3:"0px";}i:32;a:2:{i:0;s:6:"-224px";i:1;s:3:"0px";}i:48;a:2:{i:0;s:6:"-336px";i:1;s:3:"0px";}i:64;a:2:{i:0;s:6:"-448px";i:1;s:3:"0px";}}}s:16:"Add to favorites";a:3:{s:7:"favicon";s:13:"favorites.png";s:3:"url";s:28:"javascript:AddToFavorites();";s:17:"spriteCoordinates";a:4:{i:16;a:2:{i:0;s:5:"-64px";i:1;s:3:"0px";}i:32;a:2:{i:0;s:6:"-128px";i:1;s:3:"0px";}i:48;a:2:{i:0;s:6:"-192px";i:1;s:3:"0px";}i:64;a:2:{i:0;s:6:"-256px";i:1;s:3:"0px";}}}s:4:"More";a:3:{s:7:"favicon";s:8:"more.png";s:3:"url";s:18:"javascript:more();";s:17:"spriteCoordinates";a:4:{i:16;a:2:{i:0;s:3:"0px";i:1;s:3:"0px";}i:32;a:2:{i:0;s:3:"0px";i:1;s:3:"0px";}i:48;a:2:{i:0;s:3:"0px";i:1;s:3:"0px";}i:64;a:2:{i:0;s:3:"0px";i:1;s:3:"0px";}}}}', 'yes'),
(649, 'sociable_options', 'a:17:{s:5:"pixel";s:0:"";s:13:"blogplay_tags";i:1;s:7:"version";s:5:"4.3.2";s:14:"automatic_mode";s:2:"on";s:7:"tagline";s:19:"Be Sociable, Share!";s:22:"custom_image_directory";s:0:"";s:14:"use_stylesheet";s:2:"on";s:10:"use_images";s:2:"on";s:13:"use_alphamask";s:2:"on";s:10:"new_window";s:2:"on";s:9:"help_grow";s:0:"";s:9:"locations";a:2:{s:9:"is_single";s:2:"on";s:7:"is_page";s:2:"on";}s:12:"active_sites";a:16:{s:7:"Twitter";s:2:"on";s:8:"Facebook";s:2:"on";s:5:"email";s:2:"on";s:6:"vuible";s:2:"on";s:16:"Add to favorites";s:2:"on";s:11:"StumbleUpon";s:2:"on";s:9:"Delicious";s:2:"on";s:13:"Google Reader";s:2:"on";s:8:"LinkedIn";s:2:"on";s:4:"More";s:2:"on";s:15:"Twitter Counter";s:2:"on";s:16:"Facebook Counter";s:2:"on";s:8:"Google +";s:2:"on";s:16:"LinkedIn Counter";s:2:"on";s:19:"StumbleUpon Counter";s:2:"on";s:14:"vuible Counter";s:2:"on";}s:9:"icon_size";s:2:"32";s:11:"icon_option";s:7:"option1";s:6:"active";i:1;s:12:"linksoptions";s:0:"";}', 'yes'),
(650, 'sociable_helpus', '1', 'yes'),
(652, 'shareaholic_has_accepted_tos', '1', 'yes'),
(661, 'slb_version', '2.3.1', 'yes'),
(662, 'slb_options', 'a:25:{s:7:"enabled";b:1;s:12:"enabled_home";b:1;s:12:"enabled_post";b:1;s:12:"enabled_page";b:1;s:15:"enabled_archive";b:1;s:14:"enabled_widget";b:0;s:11:"group_links";b:1;s:10:"group_post";b:1;s:13:"group_gallery";b:0;s:12:"group_widget";b:0;s:10:"ui_autofit";b:1;s:10:"ui_animate";b:1;s:19:"slideshow_autostart";b:1;s:18:"slideshow_duration";s:1:"6";s:10:"group_loop";b:1;s:18:"ui_overlay_opacity";s:3:"0.8";s:16:"ui_title_default";b:0;s:11:"txt_loading";s:7:"Loading";s:9:"txt_close";s:5:"Close";s:12:"txt_nav_next";s:4:"Next";s:12:"txt_nav_prev";s:8:"Previous";s:19:"txt_slideshow_start";s:15:"Start slideshow";s:18:"txt_slideshow_stop";s:14:"Stop slideshow";s:16:"txt_group_status";s:25:"Item %current% of %total%";s:13:"theme_default";s:11:"slb_default";}', 'yes'),
(681, 'seb23_dbc_data', 'a:2:{s:7:"version";s:9:"203080024";s:13:"activatestamp";d:1410943587;}', 'yes');
INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(682, 'seb23_dbc', 'a:75:{s:10:"bu_banlist";s:1:"\n";s:12:"id_whitelist";s:0:"";s:13:"st_writefiles";i:1;s:17:"initial_filewrite";i:1;s:14:"ssl_forcelogin";s:1:"0";s:14:"ssl_forceadmin";s:1:"0";s:12:"ssl_frontend";i:1;s:14:"initial_backup";i:1;s:10:"am_enabled";s:1:"0";s:7:"am_type";s:1:"0";s:12:"am_startdate";s:1:"1";s:10:"am_enddate";s:1:"1";s:12:"am_starttime";s:1:"1";s:10:"am_endtime";s:1:"1";s:12:"backup_email";s:1:"1";s:19:"backup_emailaddress";s:0:"";s:11:"backup_time";s:1:"1";s:15:"backup_interval";s:1:"1";s:14:"backup_enabled";s:1:"0";s:11:"backup_last";s:0:"";s:11:"backup_next";s:0:"";s:17:"backups_to_retain";s:2:"10";s:10:"bu_enabled";s:1:"0";s:11:"bu_banagent";s:0:"";s:11:"za_htaccess";s:1:"0";s:10:"hb_enabled";s:1:"0";s:8:"hb_login";s:5:"login";s:11:"hb_register";s:8:"register";s:8:"hb_admin";s:5:"admin";s:6:"hb_key";s:0:"";s:10:"ll_enabled";s:1:"0";s:18:"ll_maxattemptshost";s:1:"5";s:18:"ll_maxattemptsuser";s:2:"10";s:16:"ll_checkinterval";s:1:"5";s:12:"ll_banperiod";s:2:"15";s:14:"ll_blacklistip";s:1:"1";s:23:"ll_blacklistipthreshold";s:1:"3";s:14:"ll_emailnotify";s:1:"1";s:15:"ll_emailaddress";s:0:"";s:10:"id_enabled";s:1:"0";s:14:"id_emailnotify";s:1:"1";s:16:"id_checkinterval";s:1:"5";s:12:"id_threshold";s:2:"20";s:12:"id_banperiod";s:2:"15";s:14:"id_blacklistip";s:1:"0";s:23:"id_blacklistipthreshold";s:1:"3";s:15:"id_emailaddress";s:0:"";s:14:"id_fileenabled";s:1:"0";s:18:"id_fileemailnotify";s:1:"1";s:19:"id_filedisplayerror";s:1:"1";s:19:"id_fileemailaddress";s:0:"";s:14:"id_specialfile";s:0:"";s:12:"id_fileincex";s:1:"1";s:16:"id_filechecktime";s:0:"";s:11:"st_ht_files";s:1:"0";s:14:"st_ht_browsing";s:1:"0";s:13:"st_ht_request";s:1:"0";s:11:"st_ht_query";s:1:"0";s:13:"st_ht_foreign";s:1:"0";s:12:"st_generator";s:1:"0";s:11:"st_manifest";s:1:"0";s:10:"st_edituri";s:1:"0";s:11:"st_themenot";s:1:"0";s:12:"st_pluginnot";s:1:"0";s:10:"st_corenot";s:1:"0";s:17:"st_enablepassword";s:1:"0";s:11:"st_passrole";s:13:"administrator";s:13:"st_loginerror";s:1:"0";s:11:"st_fileperm";s:1:"0";s:10:"st_comment";s:1:"0";s:16:"st_randomversion";s:1:"0";s:10:"st_longurl";s:1:"0";s:11:"st_fileedit";s:1:"0";s:8:"goo_link";s:1:"0";s:5:"start";i:1;}', 'yes'),
(698, 'finished_splitting_shared_terms', '1', 'yes'),
(699, '_transient_random_seed', 'fc4fceb20dcda007487b89acc3669743', 'yes'),
(700, '_site_transient_update_core', 'O:8:"stdClass":4:{s:7:"updates";a:1:{i:0;O:8:"stdClass":10:{s:8:"response";s:6:"latest";s:8:"download";s:63:"https://downloads.wordpress.org/release/fr_FR/wordpress-4.3.zip";s:6:"locale";s:5:"fr_FR";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:63:"https://downloads.wordpress.org/release/fr_FR/wordpress-4.3.zip";s:10:"no_content";b:0;s:11:"new_bundled";b:0;s:7:"partial";b:0;s:8:"rollback";b:0;}s:7:"current";s:3:"4.3";s:7:"version";s:3:"4.3";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"4.1";s:15:"partial_version";s:0:"";}}s:12:"last_checked";i:1441010346;s:15:"version_checked";s:3:"4.3";s:12:"translations";a:0:{}}', 'yes'),
(701, '_site_transient_update_plugins', 'O:8:"stdClass":4:{s:12:"last_checked";i:1441010346;s:8:"response";a:0:{}s:12:"translations";a:0:{}s:9:"no_update";a:2:{s:19:"akismet/akismet.php";O:8:"stdClass":6:{s:2:"id";s:2:"15";s:4:"slug";s:7:"akismet";s:6:"plugin";s:19:"akismet/akismet.php";s:11:"new_version";s:5:"3.1.3";s:3:"url";s:38:"https://wordpress.org/plugins/akismet/";s:7:"package";s:56:"https://downloads.wordpress.org/plugin/akismet.3.1.3.zip";}s:9:"hello.php";O:8:"stdClass":6:{s:2:"id";s:4:"3564";s:4:"slug";s:11:"hello-dolly";s:6:"plugin";s:9:"hello.php";s:11:"new_version";s:3:"1.6";s:3:"url";s:42:"https://wordpress.org/plugins/hello-dolly/";s:7:"package";s:58:"https://downloads.wordpress.org/plugin/hello-dolly.1.6.zip";}}}', 'yes'),
(702, '_site_transient_timeout_theme_roots', '1441012059', 'yes'),
(703, '_site_transient_theme_roots', 'a:4:{s:12:"td_wordpress";s:7:"/themes";s:13:"twentyfifteen";s:7:"/themes";s:14:"twentyfourteen";s:7:"/themes";s:14:"twentythirteen";s:7:"/themes";}', 'yes'),
(704, '_site_transient_update_themes', 'O:8:"stdClass":4:{s:12:"last_checked";i:1441010347;s:7:"checked";a:4:{s:12:"td_wordpress";s:13:"2 (2014-2015)";s:13:"twentyfifteen";s:3:"1.3";s:14:"twentyfourteen";s:3:"1.5";s:14:"twentythirteen";s:3:"1.6";}s:8:"response";a:0:{}s:12:"translations";a:2:{i:0;a:7:{s:4:"type";s:5:"theme";s:4:"slug";s:13:"twentyfifteen";s:8:"language";s:5:"fr_FR";s:7:"version";s:3:"1.3";s:7:"updated";s:19:"2015-07-27 08:39:17";s:7:"package";s:77:"https://downloads.wordpress.org/translation/theme/twentyfifteen/1.3/fr_FR.zip";s:10:"autoupdate";b:1;}i:1;a:7:{s:4:"type";s:5:"theme";s:4:"slug";s:14:"twentyfourteen";s:8:"language";s:5:"fr_FR";s:7:"version";s:3:"1.5";s:7:"updated";s:19:"2015-07-27 08:39:13";s:7:"package";s:78:"https://downloads.wordpress.org/translation/theme/twentyfourteen/1.5/fr_FR.zip";s:10:"autoupdate";b:1;}}}', 'yes'),
(705, '_site_transient_timeout_browser_f25ab87e7554638f77bc928e33909c98', '1441615060', 'yes'),
(706, '_site_transient_browser_f25ab87e7554638f77bc928e33909c98', 'a:9:{s:8:"platform";s:9:"Macintosh";s:4:"name";s:6:"Chrome";s:7:"version";s:13:"44.0.2403.157";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes'),
(707, 'can_compress_scripts', '1', 'yes'),
(708, 'theme_mods_twentyfifteen', 'a:2:{i:0;b:0;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1441010269;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:13:{i:0;s:7:"pages-2";i:1;s:10:"calendar-2";i:2;s:7:"links-2";i:3;s:6:"text-2";i:4;s:5:"rss-2";i:5;s:11:"tag_cloud-2";i:6;s:10:"nav_menu-2";i:7;s:8:"search-2";i:8;s:14:"recent-posts-2";i:9;s:17:"recent-comments-2";i:10;s:10:"archives-2";i:11;s:12:"categories-2";i:12;s:6:"meta-2";}s:9:"sidebar-1";a:2:{i:0;s:12:"categories-3";i:1;s:7:"links-3";}}}}', 'yes'),
(709, 'theme_mods_td_wordpress', 'a:1:{i:0;b:0;}', 'yes'),
(711, '_transient_is_multi_author', '0', 'yes');

-- --------------------------------------------------------

--
-- Structure de la table `wp_postmeta`
--

CREATE TABLE IF NOT EXISTS `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=453 ;

--
-- Contenu de la table `wp_postmeta`
--

INSERT INTO `wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(6, 6, '_edit_last', '1'),
(7, 6, '_wp_page_template', 'default'),
(8, 6, '_edit_lock', '1410363094:1'),
(30, 12, '_edit_last', '1'),
(31, 12, '_edit_lock', '1410363501:1'),
(89, 25, '_edit_last', '1'),
(90, 25, '_edit_lock', '1410362286:1'),
(104, 12, '_sexybookmarks_shortUrl', 'http://b2l.me/awkcdx'),
(105, 12, '_sexybookmarks_permaHash', '9035fcb9470c1e05e0aaffc7777d185c'),
(106, 40, '_edit_last', '1'),
(107, 40, '_edit_lock', '1381074844:1'),
(129, 40, '_sexybookmarks_shortUrl', 'http://b2l.me/awkfaj'),
(130, 40, '_sexybookmarks_permaHash', '26959a9cfcf5ecc3e9eeea121999950d'),
(131, 60, '_edit_last', '1'),
(132, 60, '_edit_lock', '1410934511:1'),
(135, 62, '_edit_last', '1'),
(136, 62, '_edit_lock', '1410364480:1'),
(140, 65, '_edit_last', '1'),
(141, 65, '_edit_lock', '1410934693:1'),
(144, 65, '_sexybookmarks_shortUrl', 'http://b2l.me/awkgjr'),
(145, 65, '_sexybookmarks_permaHash', '10704e0ce51ba4f1493daf39f188dc5c'),
(146, 67, '_edit_last', '1'),
(147, 67, '_edit_lock', '1348765898:1'),
(151, 71, '_edit_last', '1'),
(152, 71, '_edit_lock', '1286121533'),
(156, 75, '_edit_last', '1'),
(157, 75, '_edit_lock', '1410361917:1'),
(160, 75, '_sexybookmarks_shortUrl', 'http://b2l.me/awkh5s'),
(161, 75, '_sexybookmarks_permaHash', 'e8fe4711f233d6328f51ff01e6d5130b'),
(162, 71, '_sexybookmarks_shortUrl', 'http://b2l.me/awkj8r'),
(163, 71, '_sexybookmarks_permaHash', 'c656b03f08b163857110eb6abaf259e4'),
(164, 62, '_sexybookmarks_shortUrl', 'http://b2l.me/awkkjg'),
(165, 62, '_sexybookmarks_permaHash', 'a008a5f469ba0ff30cec0d3e21e31b3d'),
(166, 78, '_edit_last', '1'),
(167, 78, '_edit_lock', '1286121560'),
(170, 78, '_sexybookmarks_shortUrl', 'http://b2l.me/awkkyx'),
(171, 78, '_sexybookmarks_permaHash', 'e7e53b150e98a8ee541ab47605da0249'),
(173, 82, '_edit_last', '1'),
(174, 82, '_edit_lock', '1348674147:1'),
(177, 82, '_sexybookmarks_shortUrl', 'http://b2l.me/awkrfr'),
(178, 82, '_sexybookmarks_permaHash', 'd0465eb7226289f2b27e0b3fe373adbf'),
(180, 85, '_edit_last', '1'),
(181, 85, '_edit_lock', '1410937532:1'),
(184, 85, '_sexybookmarks_shortUrl', 'http://b2l.me/awktr5'),
(185, 85, '_sexybookmarks_permaHash', 'bb029b46b9b25fe9e03975dc0bec3758'),
(225, 127, '_edit_last', '1'),
(226, 127, '_edit_lock', '1348783257:1'),
(229, 127, '_sexybookmarks_shortUrl', 'http://b2l.me/awkzmb'),
(230, 127, '_sexybookmarks_permaHash', '8ac9415c890c6f73af1d0f48d8a30bb2'),
(232, 67, '_sexybookmarks_shortUrl', 'http://b2l.me/awk4f5'),
(233, 67, '_sexybookmarks_permaHash', '25059f9cb7ad3c654d759cf26d7f15d1'),
(234, 130, '_edit_last', '1'),
(235, 130, '_edit_lock', '1410364435:1'),
(238, 130, '_sexybookmarks_shortUrl', 'http://b2l.me/awk4vv'),
(239, 130, '_sexybookmarks_permaHash', 'bdc38e80cd1a5cd48d11076198a9479d'),
(240, 132, '_edit_last', '1'),
(241, 132, '_edit_lock', '1348783282:1'),
(263, 154, '_edit_last', '1'),
(264, 154, '_edit_lock', '1410274119:1'),
(299, 193, '_edit_last', '1'),
(300, 193, '_edit_lock', '1410363064:1'),
(313, 60, '_wp_old_slug', '2-1-un-plugin-social-pour-les-articles'),
(315, 65, '_wp_old_slug', '2-2-ajouter-un-effet-agrandissement-sur-les-images'),
(317, 85, '_wp_old_slug', '2-3-ajouter-un-flux-rss-avec-un-plugin'),
(322, 62, '_wp_old_slug', '1-4-ajouter-une-image-dans-un-article'),
(324, 193, '_wp_old_slug', '1-7-integrer-une-video-youtube'),
(326, 40, '_wp_old_slug', '1-3-ajouter-un-article-avec-une-date-de-publication-decallee'),
(328, 82, '_wp_old_slug', '1-5-ajouter-un-utilisateur-puis-commenter-larticle'),
(330, 154, '_wp_old_slug', '1-6-proteger-un-article-par-mot-de-passe'),
(331, 220, '_edit_last', '1'),
(332, 220, '_edit_lock', '1410363521:1'),
(451, 261, '_wp_attached_file', '2010/01/test.png'),
(452, 261, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:726;s:6:"height";i:719;s:4:"file";s:16:"2010/01/test.png";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:16:"test-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:16:"test-300x297.png";s:5:"width";i:300;s:6:"height";i:297;s:9:"mime-type";s:9:"image/png";}s:21:"shareaholic-thumbnail";a:4:{s:4:"file";s:16:"test-300x297.png";s:5:"width";i:300;s:6:"height";i:297;s:9:"mime-type";s:9:"image/png";}s:14:"post-thumbnail";a:4:{s:4:"file";s:16:"test-624x617.png";s:5:"width";i:624;s:6:"height";i:617;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}');

-- --------------------------------------------------------

--
-- Structure de la table `wp_posts`
--

CREATE TABLE IF NOT EXISTS `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=263 ;

--
-- Contenu de la table `wp_posts`
--

INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(6, 1, '2010-01-01 01:00:26', '2010-01-01 01:00:26', '<strong>Bienvenue sur wordpress !</strong>\r\n\r\nLes diapos du TD sont en téléchargement ici : <a href="http://dl.lcprod.net/iut" target="_blank">http://dl.lcprod.net/iut</a>\r\nLes codes pour l''administration : <ul><li><a href="wp-admin">Administration</a></li><li>Utilisateur : admin</li><li>Mot de passe : 1utm@t1c</li></ul> \r\n&nbsp;\r\n\r\nBesoin d''aide : Contactez moi <a title="Twitter" href="https://twitter.com/lcprod" target="_blank">@lcprod</a>', 'Informations', '', 'publish', 'closed', 'closed', '', 'cours', '', '', '2014-05-07 15:52:48', '2014-05-07 13:52:48', '', 0, 'http://127.0.0.1/TD_Wordpress/?page_id=6', 0, 'page', '', 0),
(12, 1, '2010-01-01 01:10:26', '2009-12-31 23:10:26', '<strong>Récupérer l''URL du logo :</strong>\r\n<ul>\r\n	<li>Aller sur la page de l''IUT : <a href="http://iut.univ-tours.fr" target="_blank">http://iut.univ-tours.fr</a></li>\r\n	<li>Afficher le code source de la page</li>\r\n	<li>Trouver l’url de la source de logo</li>\r\n</ul>\r\n<span style="font-weight: normal;"><strong>Indiquez le chemin absolu de cette image dans cet article :</strong></span>', '1.1 Trouver le chemin absolu du logo sur le site de l’IUT', '', 'publish', 'closed', 'closed', '', 'article-1', '', '', '2014-09-10 17:40:19', '2014-09-10 15:40:19', '', 0, 'http://127.0.0.1/TD_Wordpress/?p=12', 0, 'post', '', 0),
(25, 1, '2010-01-01 01:09:26', '2009-12-31 23:09:26', '<ul>\r\n	<li>Aller sur Google Map</li>\r\n	<li>trouver une adresse</li>\r\n	<li>Utiliser la commande en forme de roue (en bas à droite)</li>\r\n	<li>"Partager et intégrer la carte"</li>\r\n	<li>Choisir "Intégrer la carte"</li>\r\n	<li>Copier le code avec la balise "iframe"</li>\r\n	<li>Intégrer ce code à l’article "en mode HTML"</li>\r\n</ul>', '1.2 Insérer une carte GoogleMap dans cet article', '', 'publish', 'closed', 'closed', '', '1-2-inserer-une-carte-googlemap-dans-cet-article', '', '', '2014-09-10 17:20:26', '2014-09-10 15:20:26', '', 0, 'http://127.0.0.1/TD_Wordpress/?p=25', 0, 'post', '', 0),
(40, 1, '2010-01-01 01:08:26', '2010-01-01 00:08:26', '<strong>Depuis l''interface d''administration :</strong>\r\n<ul>\r\n	<li>Créer un nouvel article</li>\r\n	<li>Nommer le "L''article de 16h..."</li>\r\n	<li>Le classer dans la catégorie "TD n°1 - Modifier les articles"</li>\r\n	<li>Gérer la date de publication pour ce jour à 16h</li>\r\n</ul>', '2.1 Ajouter un article avec une date de publication décallée', '', 'publish', 'closed', 'closed', '', '2-1-ajouter-un-article-avec-une-date-de-publication-decallee', '', '', '2012-09-26 16:42:07', '2012-09-26 15:42:07', '', 0, 'http://127.0.0.1/TD_Wordpress/?p=40', 0, 'post', '', 0),
(60, 1, '2010-01-01 01:10:26', '2010-01-01 00:10:26', '<strong>Installer une extension pour proposer les liens de partage Facebook, Twitter...</strong>\r\n<ul>\r\n	<li>Télécharger le plugin ''Shareaholic'' ou ''Simple Share Buttons Adder''</li>\r\n	<li>Copier les fichiers dans le répertoire ''plugins'' de WordPress</li>\r\n	<li>Activer et configurer le plugin</li>\r\n</ul>', '5.1 Un plugin ‘social’ pour les articles', '', 'publish', 'closed', 'closed', '', '5-1-un-plugin-social-pour-les-articles', '', '', '2014-09-17 08:17:28', '2014-09-17 06:17:28', '', 0, 'http://127.0.0.1/TD_Wordpress/?p=60', 0, 'post', '', 0),
(62, 1, '2010-01-01 01:07:26', '2010-01-01 00:07:26', '<ul>\r\n	<li>Télécharger une image (de votre choix) à partir d''Internet</li>\r\n	<li>Editer cet article</li>\r\n	<li>Insérer l''image après ce texte</li>\r\n</ul>', '1.3 Ajouter une image dans un article', '', 'publish', 'closed', 'closed', '', '1-3-ajouter-une-image-dans-un-article', '', '', '2014-09-10 17:57:01', '2014-09-10 15:57:01', '', 0, 'http://127.0.0.1/TD_Wordpress/?p=62', 0, 'post', '', 0),
(65, 1, '2010-01-01 01:09:26', '2010-01-01 00:09:26', '<ul>\r\n	<li>Récupérer le plugin "Simple Lightbox"</li>\r\n	<li>Installer le plugin</li>\r\n	<li>Vérifiez que les images des articles possèdent un lien (sinon créer le lien vers la source de l''image)</li>\r\n	<li>Tester le fonctionnement</li>\r\n</ul>', '5.2 Ajouter un effet ‘Agrandissement’ sur les images', '', 'publish', 'closed', 'closed', '', '5-2-ajouter-un-effet-agrandissement-sur-les-images', '', '', '2014-09-17 08:20:24', '2014-09-17 06:20:24', '', 0, 'http://127.0.0.1/TD_Wordpress/?p=65', 0, 'post', '', 0),
(67, 1, '2010-01-01 01:10:26', '2009-12-31 23:10:26', '<strong>A partir de l''interface d''administration :</strong>\r\n<ul>\r\n	<li>Accéder aux Widgets</li>\r\n	<li>Ajouter ''Nuage de mots-clefs'' à la ''Sidebar''</li>\r\n</ul>', '3.1 Ajouter un ‘nuage de mots-clefs’ dans la barre', '', 'publish', 'closed', 'closed', '', '3-1-ajouter-un-nuage-de-mots-cles-dans-la-barre', '', '', '2010-10-03 17:58:48', '2010-10-03 15:58:48', '', 0, 'http://127.0.0.1/TD_Wordpress/?p=67', 0, 'post', '', 0),
(71, 1, '2010-01-01 01:09:26', '2009-12-31 23:09:26', 'Depuis l''interface d''administration :\r\n<ul>\r\n	<li>Acceder aux Widgets</li>\r\n	<li>Ajouter un bloc "Texte"</li>\r\n</ul>', '3.2 Ajouter un pied de page personnalisé', '', 'publish', 'closed', 'closed', '', '3-2-ajouter-un-pied-de-page-personnalise', '', '', '2010-10-03 17:58:53', '2010-10-03 15:58:53', '', 0, 'http://127.0.0.1/TD_Wordpress/?p=71', 0, 'post', '', 0),
(75, 1, '2010-01-01 01:10:26', '2009-12-31 23:10:26', '<strong>Depuis les fichiers du thème :</strong>\r\n<ul>\r\n	<li>Ouvrer la feuille de style ''style.css''</li>\r\n	<li>Retrouver le style ''a'' qui formate les liens</li>\r\n	<li>Modifier la couleur</li>\r\n</ul>', '4.1 Modifier la couleur des liens', '', 'publish', 'closed', 'closed', '', '4-1-modifier-la-couleur-des-liens', '', '', '2010-10-03 17:59:15', '2010-10-03 15:59:15', '', 0, 'http://127.0.0.1/TD_Wordpress/?p=75', 0, 'post', '', 0),
(78, 1, '2010-01-01 01:09:26', '2009-12-31 23:09:26', '<strong>Retrouver le style qui affiche la bannière :</strong>\r\n<ul>\r\n	<li>Avec Safari : Sur la bannière -&gt; Click droit -&gt; "Procéder à l''inspection du document".</li>\r\n	<li>Identifier le style qui affiche la bannière</li>\r\n</ul>\r\n<strong>Modifier le style :</strong>\r\n<ul>\r\n	<li>Ouvrer la feuille de style ''style.css''</li>\r\n	<li>Identifier le style</li>\r\n	<li>Utiliser une autre image</li>\r\n</ul>', '4.2 Changer la bannière du site', '', 'publish', 'closed', 'closed', '', '4-2-changer-la-banniere-du-site', '', '', '2010-10-03 17:59:20', '2010-10-03 15:59:20', '', 0, 'http://127.0.0.1/TD_Wordpress/?p=78', 0, 'post', '', 0),
(82, 1, '2010-01-01 01:06:26', '2010-01-01 00:06:26', '<strong>Depuis l''interface d''administration :</strong>\r\n<ul>\r\n	<li>Ajouter vous comme utilisateur ''Abonné'' sur le site</li>\r\n	<li>Logger vous sous ce nouvel utilisateur</li>\r\n	<li>Commenter cet article</li>\r\n	<li>Retourner en ''Administrateur'' et validez le commentaire</li>\r\n</ul>', '2.2 Ajouter un utilisateur puis commenter l’article', '', 'publish', 'open', 'closed', '', '2-2-ajouter-un-utilisateur-puis-commenter-larticle', '', '', '2012-09-26 16:42:27', '2012-09-26 15:42:27', '', 0, 'http://127.0.0.1/TD_Wordpress/?p=82', 0, 'post', '', 0),
(85, 1, '2010-01-01 01:08:26', '2010-01-01 00:08:26', 'Récupérez le plugin ''Simple Feed List''\r\n<a href="http://dl.lcprod.net/iut/CMS%20Wordpress/Documents/wordpress/wordpress_SimpleFeedList.zip">http://dl.lcprod.net/iut/CMS%20Wordpress/Documents/wordpress/wordpress_SimpleFeedList.zip</a>\r\n\r\n<strong>Dans Wordpress :</strong>\r\n<ul>\r\n	<li>Installez le plugin et activez le</li>\r\n</ul>\r\n<strong>Dans les fichiers du site</strong>\r\n<ul>\r\n	<li>Ouvrez ''sidebar.php''</li>\r\n	<li>Ajouter le code suivant dans la section définie par "&lt;div id=''myPlugin''&gt;" .... et "&lt;/div&gt;"</li>\r\n</ul>\r\n<div style="padding-left: 30px;">------------------------------------------------------------------</div>\r\n<div style="padding-left: 30px;">&lt;h3&gt;News MacGeneration&lt;/h3&gt;\r\n&lt;?php simple_feed_list(''http://rss.macgeneration.com/'',''limit=5''); ?&gt;</div>\r\n<div style="padding-left: 30px;">------------------------------------------------------------------</div>', '5.3 Ajouter un flux RSS avec un plugin', '', 'publish', 'closed', 'closed', '', '5-3-ajouter-un-flux-rss-avec-un-plugin', '', '', '2014-09-17 09:07:39', '2014-09-17 07:07:39', '', 0, 'http://127.0.0.1/TD_Wordpress/?p=85', 0, 'post', '', 0),
(127, 1, '2010-01-01 01:08:26', '2010-01-01 00:08:26', '<strong>Retrouver le style qui gère les titres :</strong>\r\n<ul>\r\n	<li>Avec Safari : Sur la bannière -&gt; Click droit -&gt; « Procéder à l’inspection du document ».</li>\r\n	<li>Identifier le style qui affiche la bannière</li>\r\n</ul>\r\n<strong>Modifier le style :</strong>\r\n<ul>\r\n	<li>Ouvrer la feuille de style ‘style.css’</li>\r\n	<li>Identifier le style</li>\r\n	<li>Utiliser une autre police/couleur/...</li>\r\n</ul>', '4.3 Modifier la police des titres des articles', '', 'publish', 'closed', 'closed', '', '4-3-modifier-la-police-des-titres-des-articles', '', '', '2012-09-27 23:00:57', '2012-09-27 22:00:57', '', 0, 'http://127.0.0.1/TD_Wordpress/?p=127', 0, 'post', '', 0),
(130, 1, '2010-01-01 01:08:26', '2010-01-01 00:08:26', '<strong>Depuis les fichiers du thème :</strong>\r\n<ul>\r\n	<li>Ouvrer "single.php"</li>\r\n	<li>Réactiver le code des méta-données</li>\r\n</ul>', '3.3 Afficher les méta-données des articles', '', 'publish', 'closed', 'closed', '', '3-3-afficher-les-meta-donnees-des-articles', '', '', '2012-09-27 23:01:06', '2012-09-27 22:01:06', '', 0, 'http://127.0.0.1/TD_Wordpress/?p=130', 0, 'post', '', 0),
(132, 1, '2010-01-01 01:07:26', '2010-01-01 00:07:26', '<strong>Depuis les fichiers du thème :</strong>\r\n<ul>\r\n	<li>Réactiver le code qui propose le lien vers Wordpress.</li>\r\n</ul>', '3.4 Afficher le lien WordPress en pied de page', '', 'publish', 'closed', 'closed', '', '3-4-afficher-le-lien-wordpress-en-pied-de-page', '', '', '2012-09-27 23:01:22', '2012-09-27 22:01:22', '', 0, 'http://127.0.0.1/TD_Wordpress/?p=132', 0, 'post', '', 0),
(154, 1, '2010-01-01 01:05:34', '2010-01-01 00:05:34', '<strong>Dans l''interface d''administration de Wordpress :</strong>\r\n<ul>\r\n	<li>Editer cet article</li>\r\n	<li>Modifier la visibilité de l''article pour gérer un mot de passe</li>\r\n	<li>Publier en ligne</li>\r\n</ul>\r\n<strong>Expliquer la différence entre ''Privé'' et Protégé par mot de passe'' dans un commentaire de cet article.</strong>', '2.3 Protéger un article par mot de passe', '', 'publish', 'open', 'closed', '', '2-3-proteger-un-article-par-mot-de-passe', '', '', '2014-09-09 16:44:42', '2014-09-09 14:44:42', '', 0, 'http://127.0.0.1/TD_Wordpress/?p=154', 0, 'post', '', 0),
(193, 1, '2010-01-01 01:04:25', '2010-01-01 00:04:25', '<span style="line-height: 13px;"><strong>Ajouter une vidéo Youtube dans un article :</strong></span>\r\n<ul>\r\n	<li><span style="line-height: 13px;">Trouver la vidéo sur <a title="Youtube" href="http://www.youtube.com/" target="_blank">Youtube</a> de Norman "LES APPLE ADDICT"</span></li>\r\n	<li><span style="line-height: 13px;">Copier le code d''intégration (balise iframe) depuis la vidéo (click droit sur la vidéo)</span></li>\r\n	<li><span style="line-height: 13px;">Intégrer ce code à l’article ‘en mode HTML’</span></li>\r\n</ul>', '1.4 Intégrer une vidéo Youtube', '', 'publish', 'closed', 'closed', '', '1-4-integrer-une-video-youtube', '', '', '2014-09-10 17:21:04', '2014-09-10 15:21:04', '', 0, 'http://127.0.0.1/wordpress/?p=193', 0, 'post', '', 0),
(220, 1, '2010-01-01 01:04:25', '2010-01-01 00:04:25', '<strong>Modifier l''état de cet article pour la passer de "Publié" vers "Brouillon"</strong>', '2.4 Modifier l''état d''un article (Brouillon)', '', 'publish', 'closed', 'closed', '', '2-4-modifier-letat-dun-article-brouillon', '', '', '2014-09-10 17:41:00', '2014-09-10 15:41:00', '', 0, 'http://127.0.0.1/wordpress/?p=220', 0, 'post', '', 0),
(261, 1, '2014-09-17 08:19:39', '2014-09-17 06:19:39', '', 'test', '', 'inherit', 'closed', 'closed', '', 'test', '', '', '2014-09-17 08:19:39', '2014-09-17 06:19:39', '', 65, 'http://127.0.0.1/wordpress/wp-content/uploads/2010/01/test.png', 0, 'attachment', 'image/png', 0),
(262, 1, '2015-08-31 10:37:40', '0000-00-00 00:00:00', '', 'Brouillon auto', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2015-08-31 10:37:40', '0000-00-00 00:00:00', '', 0, 'http://127.0.0.1/wordpress/?p=262', 0, 'post', '', 0);

-- --------------------------------------------------------

--
-- Structure de la table `wp_terms`
--

CREATE TABLE IF NOT EXISTS `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=19 ;

--
-- Contenu de la table `wp_terms`
--

INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'TD n°1 - Modifier les articles', 'td1', 0),
(2, 'Liens', 'liens', 0),
(6, 'TD n°4 - Modifier les styles', 'td4', 0),
(8, 'TD n°5 - Utiliser les plugins', 'td5', 0),
(9, 'TD n°3 - Modifier la structure de la page', 'td3', 0),
(10, 'plugins', 'plugins', 0),
(11, 'Utilisateurs', 'utilisateurs', 0),
(12, 'CSS', 'css', 0),
(13, 'Structure', 'structure', 0),
(14, 'Articles', 'articles', 0),
(16, 'TD n°2 - Comprendre les Workflows', 'td2', 0),
(17, 'PHP', 'php', 0),
(18, 'Menu 1', 'menu-1', 0);

-- --------------------------------------------------------

--
-- Structure de la table `wp_term_relationships`
--

CREATE TABLE IF NOT EXISTS `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Contenu de la table `wp_term_relationships`
--

INSERT INTO `wp_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(5, 2, 0),
(6, 2, 0),
(8, 2, 0),
(9, 2, 0),
(12, 1, 0),
(12, 14, 0),
(25, 1, 0),
(25, 14, 0),
(40, 14, 0),
(40, 16, 0),
(60, 8, 0),
(60, 10, 0),
(62, 1, 0),
(62, 14, 0),
(65, 8, 0),
(65, 10, 0),
(67, 9, 0),
(67, 10, 0),
(71, 9, 0),
(71, 13, 0),
(75, 6, 0),
(75, 12, 0),
(78, 6, 0),
(78, 12, 0),
(82, 11, 0),
(82, 16, 0),
(85, 8, 0),
(85, 10, 0),
(127, 6, 0),
(127, 12, 0),
(130, 9, 0),
(130, 17, 0),
(132, 9, 0),
(132, 17, 0),
(154, 14, 0),
(154, 16, 0),
(193, 1, 0),
(193, 14, 0),
(220, 14, 0),
(220, 16, 0);

-- --------------------------------------------------------

--
-- Structure de la table `wp_term_taxonomy`
--

CREATE TABLE IF NOT EXISTS `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=19 ;

--
-- Contenu de la table `wp_term_taxonomy`
--

INSERT INTO `wp_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 4),
(2, 2, 'link_category', '', 0, 4),
(6, 6, 'category', '', 0, 3),
(8, 8, 'category', '', 0, 3),
(9, 9, 'category', '', 0, 4),
(10, 10, 'post_tag', '', 0, 4),
(11, 11, 'post_tag', '', 0, 1),
(12, 12, 'post_tag', '', 0, 3),
(13, 13, 'post_tag', '', 0, 1),
(14, 14, 'post_tag', '', 0, 7),
(16, 16, 'category', '', 0, 4),
(17, 17, 'post_tag', '', 0, 2),
(18, 18, 'nav_menu', '', 0, 0);

-- --------------------------------------------------------

--
-- Structure de la table `wp_usermeta`
--

CREATE TABLE IF NOT EXISTS `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=71 ;

--
-- Contenu de la table `wp_usermeta`
--

INSERT INTO `wp_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'first_name', ''),
(2, 1, 'last_name', ''),
(3, 1, 'nickname', 'admin'),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'comment_shortcuts', 'false'),
(7, 1, 'admin_color', 'fresh'),
(8, 1, 'use_ssl', '0'),
(9, 1, 'aim', ''),
(10, 1, 'yim', ''),
(11, 1, 'jabber', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";s:1:"1";}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'wp_dashboard_quick_press_last_post_id', '262'),
(15, 1, 'wp_user-settings', 'm6=c&m5=c&m7=c&m8=c&m9=c&editor=tinymce&m1=c&hidetb=1&m4=c&libraryContent=browse&posts_list_mode=list&imgsize=thumbnail'),
(16, 1, 'wp_user-settings-time', '1410934789'),
(17, 1, 'managenav-menuscolumnshidden', 'a:4:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";}'),
(18, 1, 'metaboxhidden_nav-menus', 'a:2:{i:0;s:8:"add-post";i:1;s:12:"add-post_tag";}'),
(19, 1, 'nav_menu_recently_edited', '18'),
(20, 1, 'closedpostboxes_dashboard', 'a:1:{i:0;s:17:"dashboard_primary";}'),
(21, 1, 'metaboxhidden_dashboard', 'a:2:{i:0;s:18:"dashboard_activity";i:1;s:17:"dashboard_primary";}'),
(22, 1, 'meta-box-order_dashboard', 'a:4:{s:6:"normal";s:44:"dashboard_right_now,dashboard_incoming_links";s:4:"side";s:127:"dashboard_quick_press,dashboard_recent_comments,dashboard_recent_drafts,dashboard_primary,dashboard_secondary,dashboard_plugins";s:7:"column3";s:0:"";s:7:"column4";s:0:"";}'),
(23, 1, 'screen_layout_dashboard', '2'),
(37, 1, 'closedpostboxes_post', 'a:0:{}'),
(38, 1, 'metaboxhidden_post', 'a:6:{i:0;s:13:"trackbacksdiv";i:1;s:10:"postcustom";i:2;s:16:"commentstatusdiv";i:3;s:11:"commentsdiv";i:4;s:7:"slugdiv";i:5;s:9:"authordiv";}'),
(39, 1, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_media_uploader,wp330_saving_widgets,wp350_media,wp390_widgets,wp360_revisions'),
(40, 1, 'show_admin_bar_front', 'true'),
(66, 1, 'show_welcome_panel', '0'),
(67, 1, 'closedpostboxes_page', 'a:0:{}'),
(68, 1, 'metaboxhidden_page', 'a:5:{i:0;s:12:"revisionsdiv";i:1;s:10:"postcustom";i:2;s:11:"commentsdiv";i:3;s:7:"slugdiv";i:4;s:9:"authordiv";}'),
(69, 1, 'session_tokens', 'a:1:{s:64:"0568258bace2c2f17ade473dec9dda2afab376db93bb8ac798c838ab7c6004f3";a:4:{s:10:"expiration";i:1442219857;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:121:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36";s:5:"login";i:1441010257;}}'),
(70, 1, 'wp_media_library_mode', 'grid');

-- --------------------------------------------------------

--
-- Structure de la table `wp_users`
--

CREATE TABLE IF NOT EXISTS `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=2 ;

--
-- Contenu de la table `wp_users`
--

INSERT INTO `wp_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'admin', '$P$BVe17cXWhJUxeqlZaEoRxWbe93hhYv/', 'admin', 'iutmatic@gmail.com', '', '2010-09-30 16:31:23', '', 0, 'admin');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
